/********************************************************************************
** Form generated from reading UI file 'serverdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SERVERDIALOG_H
#define UI_SERVERDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_ServerDialog
{
public:
    QGridLayout *gridLayout;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *ButtonFile;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *ButtonClose;
    QVBoxLayout *verticalLayout;
    QListWidget *listWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *portEdit;
    QPushButton *createButton;
    QPushButton *ButtonSend;

    void setupUi(QDialog *ServerDialog)
    {
        if (ServerDialog->objectName().isEmpty())
            ServerDialog->setObjectName(QString::fromUtf8("ServerDialog"));
        ServerDialog->resize(416, 368);
        gridLayout = new QGridLayout(ServerDialog);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        horizontalSpacer_3 = new QSpacerItem(19, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_3, 1, 2, 1, 1);

        ButtonFile = new QPushButton(ServerDialog);
        ButtonFile->setObjectName(QString::fromUtf8("ButtonFile"));

        gridLayout->addWidget(ButtonFile, 1, 3, 1, 1);

        horizontalSpacer_4 = new QSpacerItem(19, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_4, 1, 4, 1, 1);

        ButtonClose = new QPushButton(ServerDialog);
        ButtonClose->setObjectName(QString::fromUtf8("ButtonClose"));

        gridLayout->addWidget(ButtonClose, 1, 5, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        listWidget = new QListWidget(ServerDialog);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));

        verticalLayout->addWidget(listWidget);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(ServerDialog);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(20);
        label->setFont(font);

        horizontalLayout->addWidget(label);

        portEdit = new QLineEdit(ServerDialog);
        portEdit->setObjectName(QString::fromUtf8("portEdit"));
        portEdit->setFont(font);

        horizontalLayout->addWidget(portEdit);


        verticalLayout->addLayout(horizontalLayout);

        createButton = new QPushButton(ServerDialog);
        createButton->setObjectName(QString::fromUtf8("createButton"));
        createButton->setFont(font);
        createButton->setStyleSheet(QString::fromUtf8(""));

        verticalLayout->addWidget(createButton);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 6);

        ButtonSend = new QPushButton(ServerDialog);
        ButtonSend->setObjectName(QString::fromUtf8("ButtonSend"));

        gridLayout->addWidget(ButtonSend, 1, 0, 1, 2);


        retranslateUi(ServerDialog);

        QMetaObject::connectSlotsByName(ServerDialog);
    } // setupUi

    void retranslateUi(QDialog *ServerDialog)
    {
        ServerDialog->setWindowTitle(QCoreApplication::translate("ServerDialog", "\350\201\212\345\244\251\345\256\244\346\234\215\345\212\241\345\231\250", nullptr));
        ButtonFile->setText(QCoreApplication::translate("ServerDialog", "\344\274\240\350\276\223\346\226\207\344\273\266", nullptr));
        ButtonClose->setText(QCoreApplication::translate("ServerDialog", "\346\226\255\345\274\200\350\277\236\346\216\245", nullptr));
        label->setText(QCoreApplication::translate("ServerDialog", "\346\234\215\345\212\241\345\231\250\347\253\257\345\217\243\357\274\232", nullptr));
        portEdit->setText(QCoreApplication::translate("ServerDialog", "8080", nullptr));
        createButton->setText(QCoreApplication::translate("ServerDialog", "\345\210\233\345\273\272\346\234\215\345\212\241\345\231\250", nullptr));
        ButtonSend->setText(QCoreApplication::translate("ServerDialog", "\345\217\221\351\200\201", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ServerDialog: public Ui_ServerDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SERVERDIALOG_H
