/********************************************************************************
** Form generated from reading UI file 'ServerFile.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SERVERFILE_H
#define UI_SERVERFILE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ServerFile
{
public:
    QGridLayout *gridLayout;
    QSpacerItem *horizontalSpacer;
    QLabel *label;
    QSpacerItem *horizontalSpacer_2;
    QTextEdit *textEdit;
    QPushButton *ButtonChance;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *pushButton_3;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *ButtonSend;

    void setupUi(QWidget *ServerFile)
    {
        if (ServerFile->objectName().isEmpty())
            ServerFile->setObjectName(QString::fromUtf8("ServerFile"));
        ServerFile->resize(650, 363);
        gridLayout = new QGridLayout(ServerFile);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        horizontalSpacer = new QSpacerItem(91, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 0, 0, 1, 1);

        label = new QLabel(ServerFile);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setFamily(QString::fromUtf8("\346\245\267\344\275\223"));
        font.setPointSize(28);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);

        gridLayout->addWidget(label, 0, 1, 1, 3);

        horizontalSpacer_2 = new QSpacerItem(91, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 0, 4, 1, 1);

        textEdit = new QTextEdit(ServerFile);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));

        gridLayout->addWidget(textEdit, 1, 0, 1, 5);

        ButtonChance = new QPushButton(ServerFile);
        ButtonChance->setObjectName(QString::fromUtf8("ButtonChance"));

        gridLayout->addWidget(ButtonChance, 2, 0, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(158, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_3, 2, 1, 1, 1);

        pushButton_3 = new QPushButton(ServerFile);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        gridLayout->addWidget(pushButton_3, 2, 2, 1, 1);

        horizontalSpacer_4 = new QSpacerItem(157, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_4, 2, 3, 1, 1);

        ButtonSend = new QPushButton(ServerFile);
        ButtonSend->setObjectName(QString::fromUtf8("ButtonSend"));

        gridLayout->addWidget(ButtonSend, 2, 4, 1, 1);


        retranslateUi(ServerFile);

        QMetaObject::connectSlotsByName(ServerFile);
    } // setupUi

    void retranslateUi(QWidget *ServerFile)
    {
        ServerFile->setWindowTitle(QCoreApplication::translate("ServerFile", "Form", nullptr));
        label->setText(QCoreApplication::translate("ServerFile", "\346\234\215\345\212\241\345\231\250\344\274\240\350\276\223\346\226\207\344\273\266\347\252\227\345\217\243", nullptr));
        ButtonChance->setText(QCoreApplication::translate("ServerFile", "\351\200\211\346\213\251\346\226\207\344\273\266", nullptr));
        pushButton_3->setText(QCoreApplication::translate("ServerFile", "\350\277\224\345\233\236\350\201\212\345\244\251\347\252\227\345\217\243", nullptr));
        ButtonSend->setText(QCoreApplication::translate("ServerFile", "\345\217\221\351\200\201\346\226\207\344\273\266", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ServerFile: public Ui_ServerFile {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SERVERFILE_H
