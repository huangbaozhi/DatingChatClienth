#include <iostream>
#include "server.h"

using namespace std;

int main()
{
	//创建服务器对象
	Server s(IP, PORT);

	return 0;
}