#ifndef QSETWIDGET_H
#define QSETWIDGET_H

#include <QWidget>
#include <QTcpSocket>

class QListWidget;
class QInforMationWidget;
class QPushButton;
class QStackedWidget;

class QSetWidget : public QWidget
{
    Q_OBJECT
public:
    explicit QSetWidget(QTcpSocket *socket, QString fri, QString group, QString userName, QWidget *parent = nullptr);

signals:
    void  signSwicthON();   // 语音播报开启
    void  signSwicthOFF();  // 语音播报关闭

private:
    void initUI();

private slots:
    void slotRealNameAud();     // 个人认证槽
    void slotViewChatRecord();  // 查看聊天记录
    void turnPages();

public slots:
    void slotSwicthON();        // 开启
    void slotSwicthOFF();       // 关闭
    void slotGetAccount(QString account);// 传入账号

private:
    QListWidget* m_pListWidget;
    QInforMationWidget* m_pInforMationWidget;
    QPushButton* m_pChatRecordBtn;
    QStackedWidget* m_pStackedWidget;
    QPushButton* m_pDetailsBtn;
};

#endif // QSETWIDGET_H
