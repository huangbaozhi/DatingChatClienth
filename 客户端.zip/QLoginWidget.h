#ifndef QLOGINWIDGET_H
#define QLOGINWIDGET_H

#include <QDialog>
#include <QTcpSocket>
#include <QHostAddress>
#include <QMessageBox>
#include <QDebug>
#include <QTcpSocket>
#include <QHostAddress>
#include <QMessageBox>
#include <QJsonObject>
#include <QJsonDocument>
#include "chatlist.h"
#include <QPixmap>

class QLineEdit;
class QFaceOCR;
class DatingChatClient;
class QRegisterWidget;
class QHeadImage;

class QLoginWidget : public QDialog
{
    Q_OBJECT
public:
    explicit QLoginWidget(QWidget *parent = nullptr);

signals:
    void signLogin();// 登录信号
    void signGetAccountID(QString str);//获取账号id

    void signLoginUserName();//获取登录用户名

    void signHeadImage(QPixmap pixmap);

private:
    void initUI();// 初始化界面

private slots:
    void slotLogin();       // 登录槽
    void slotRegister();    // 注册槽
    void slotFace();        // 人脸识别
    void slotDatingChatWnd();   // 聊天界面

    void slotHeadImage();
    void slotClientConnetServer();

public slots:
    QString GetAccountID();// 获取账号ID

private slots:
    void connect_success();
    void server_reply();

    void on_registerButton_clicked();

    void on_loginButton_clicked();

private:
    void client_register_handler(QString);
    void client_login_handler(QString, QString, QString);

    QTcpSocket *socket;
    QString userName;


private:
    QLineEdit* m_pUserLineEdit;//账号
    QLineEdit* m_pPwdLineEdit;//密码

    QFaceOCR* m_pFaceOCR;//人脸识别
    DatingChatClient* m_pDatingChatClient;//消息界面

    QRegisterWidget* m_pRegisterWidget;//注册

    QHeadImage *m_pheadImage;//头像
    DatingChatClient *m_c;//消息界面
};

#endif // QLOGINWIDGET_H
