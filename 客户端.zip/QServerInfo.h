#ifndef QSERVERINFO_H
#define QSERVERINFO_H

#include <QDialog>

class QPushButton;
class QStackedWidget;
class QLineEdit;
class QListWidget;
class QHBoxLayout;

class QServerInfo : public QDialog
{
    Q_OBJECT
public:
    explicit QServerInfo(QWidget *parent = nullptr);

signals:

public:
    QString GetUserName();

private:
    void initUI();

private slots:
    void WriteIni();

private:
    QListWidget* m_pListWidget;
    QLineEdit* m_pSendEdit;
    QPushButton* m_pSendBtn;
    QLineEdit* m_pServerEdit;
    QLineEdit* m_pPortEdit;
    QLineEdit* m_pUserNameEdit;
    QPushButton* m_pConnectButton;

};

#endif // QSERVERINFO_H
