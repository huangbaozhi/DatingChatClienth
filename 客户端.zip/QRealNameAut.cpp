﻿#include "QRealNameAut.h"
#include "ui_QRealNameAut.h"
//#include "QCAuthenticationWnd.h"
//#include "QCAuthentication.h"
#include "QIniConfig.h"
#include "QRBaseWidget.h"
#include "QMovableWindow.h"
#include "ConfigIni.h"

#include <QPixmap>
#include <QCamera>
#include <QCameraViewfinder>
#include <QCameraImageCapture>
#include <QRadioButton>

QRealNameAut::QRealNameAut(QWidget *parent)
    :QRBaseWidget(parent),
    ui(new Ui::QRealNameAut)
{
    ui->setupUi(this);
    (void)new QMovableWindow(this);

    this->setStyleSheet("QWidget{border: 1px solid #707070;}");

    // 读取配置
    ui->namelineEdit->setText(ConfigIni().GetRealNameAutIni());
    ui->idlineEdit->setText(ConfigIni().GetRealIdAutIni());

    //创建百度识别类的对象
    //百度AI初始化
    QString apiKey = "tyaiBIstskWgzn1C3ogxTR8b";
    QString secretKey = "ksjdd0Frpm4Hvoco8o4bAmfSGtZUlU6Q";
    mBaiOCR = new QBaiOCR(apiKey,secretKey);
    connect(mBaiOCR,&QBaiOCR::ocrResult,this,&QRealNameAut::on_OcrResult);

    connect(ui->backBtn, SIGNAL(clicked(bool)), this, SLOT(slotbackBtn()));

    connect(ui->pushButton_4,&QPushButton::clicked,this,&QRealNameAut::OrcBtn2);
    connect(ui->pushButton_4,&QPushButton::clicked,this,&QRealNameAut::OrcBtn);
}

QRealNameAut::~QRealNameAut()
{
    delete ui;
}

// 身份证——正面
void QRealNameAut::on_pushButton_clicked()
{
    QString filename = QFileDialog::getOpenFileName(this, "请选择图片", nullptr,"*.jpg");
    ui->lineEdit->setText(filename);
    ui->image->setPixmap(QPixmap(filename));
}

//身份证——反面
void QRealNameAut::on_pushButton_2_clicked()
{
    QString filename = QFileDialog::getOpenFileName(this, "请选择图片", nullptr,"*.jpg");
    ui->lineEdit_2->setText(filename);
    ui->image_2->setPixmap(QPixmap(filename));
}

// 正面_路径显示
void QRealNameAut::OrcBtn()
{
    mBaiOCR->recgIdCard(ui->lineEdit->text());
}

// 反面_路径显示
void QRealNameAut::OrcBtn2()
{
    mBaiOCR->recgIdCard(ui->lineEdit_2->text());
}

//识别结果的槽函数
void QRealNameAut::on_OcrResult(QBaiOCR::OCR_RET ret, QBaiOCR::OCR_TYPE type)
{
    if(ret == QBaiOCR::OCR_SUCCESS){
        switch (type) {
        case QBaiOCR::OCR_ID_CARD:
            ui->namelineEdit->setText(mBaiOCR->getIdCard()->toString());
            ui->idlineEdit->setText(mBaiOCR->getIdCard()->toStringID());
            mBaiOCR->getIdCard()->toStringNational();

            qDebug()<<"识别成功";
            ui->resultBtn->setText("成功认证");

            emit sigIconLbl(); // 识别成功显示认证图标发送信号到QCA

            break;
        default:
            break;
        }
    }else{
        ui->resultBtn->setText("识别失败");
        qDebug()<<"识别失败";
    }
}

// 返回栈布局的第一页
void QRealNameAut::slotbackBtn()
{
    emit sigBackBtn();
}

// 写入配置
void QRealNameAut::WriteIni()
{
    qDebug()<<"[QRealNameAut::WriteIni]"<<ui->namelineEdit->text();
    ConfigIni().SetRealNameAutIni(ui->namelineEdit->text(),ui->idlineEdit->text());
}

// 是否同意提交认证
void QRealNameAut::on_checkBox_stateChanged(int arg1)
{
    bool bEnable = arg1== Qt::Checked?true:false;

    if(ui->pushButton_4!=NULL)
    {
        if(bEnable)
        {
            ui->pushButton_4->setStyleSheet("QPushButton{border-image: url(:/botton/SubmitBrn_hover.png);}");
        }
        else
        {
            ui->pushButton_4->setStyleSheet("QPushButton{border-image: url(:/botton/SubmitBtn.png);}");
        }
    }
    ui->pushButton_4->setEnabled(bEnable);
}

// 保存
void QRealNameAut::on_saveBtn_clicked()
{
    WriteIni();
}



void QRealNameAut::on_backBtn_clicked()
{
    this->close();
}
