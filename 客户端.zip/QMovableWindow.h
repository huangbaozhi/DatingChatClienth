#pragma once

#include <QObject>
#include <QPoint>

class QWidget;

class QMovableWindow : public QObject
{
	Q_OBJECT

public:
	explicit QMovableWindow(QWidget *parent = nullptr);
	~QMovableWindow();

public:
	bool  eventFilter(QObject *watched, QEvent *event);

protected:
	QWidget* m_pWatching;
	QPoint m_pos;		// ��갴��ʱ��λ��
	bool m_bDown;		// ����Ƿ���
};
