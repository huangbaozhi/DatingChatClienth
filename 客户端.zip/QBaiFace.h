﻿#ifndef QBAIFACE_H
#define QBAIFACE_H

#include <QWidget>

#include <QUrl>

#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QByteArray>
#include <QEventLoop>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QRect>

class QBaiFace : public QWidget
{
    Q_OBJECT
public:
    enum BAI_RET
    {
        BAI_SUCCESS,
        BAI_SUCCESS_MATCH,
        BAI_SUCCESS_SEARCH,
        BAI_ERROR,
        BAI_ERROR_RECG,          //识别错误
        BAI_ERROR_NOTHING,       //没有要识别的信息
        BAI_ERROR_IMG,
        BAI_ERROR_PARAM,         //参数错误
        BAI_ERROR_FORMAT,        //参数错误
        BAI_ERROR_BUSY,          //繁忙
        BAI_ERROR_COMMU,         //通信错误
        BAI_ERROR_TIMEOUT,       //执行超时
        BAI_ERROR_OTHER,         //其余错误
    };
    Q_ENUM(BAI_RET)

    //识别证件类型
    enum FACE_FIELD
    {
        DEFAULT     = 0b0,
        AGE         = 0b1,      //年龄
        GENDER      = 0b10000,  // 性别
    };
    Q_ENUM(FACE_FIELD)

    //身份证识别结果
    class FaceInfo{
    public:
        QString face_token;
        QRect location;
        int rotation;
        double age;
        QPair<QString,double> gender;//type,probability  male:男性 female:女性

        FaceInfo() {}
    };

    //构造函数
    QBaiFace();
    QBaiFace(QString apiKey, QString secretKey);

private:
    QString bai_apiKey, bai_secretKey, bai_token;
    QNetworkAccessManager *manager;
    QNetworkReply *pReplay;

    quint32 face_field;
    QEventLoop eventLoop;

    void Access_to_http(QString Url, QByteArray data);
    QString getBai_token(QString ApiKey, QString SecretKey);

    FaceInfo& parseJsonFace(QJsonObject &subObj);
    void recgImage(QString baiUrl, QString fpath);

signals:
    void httpFinish(QByteArray);
    void baiResult(BAI_RET ret);

public slots:
    bool recgFace(QString fpath, quint32 field);//类型为32位

private slots:
    void replyFinished(QNetworkReply *reply);

};

#endif // QBAIFACE_H
