#include "WriteConfigIni.h"

WriteConfigIni::WriteConfigIni(QWidget *parent) : QWidget(parent)
{

}

void WriteConfigIni::WriteIni()
{

}
