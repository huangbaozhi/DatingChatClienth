#ifndef PICTUREPREVIEWPANEL_H
#define PICTUREPREVIEWPANEL_H

#include <QWidget>

//class PicturePreviewPanel : public QWidget
//{
//    Q_OBJECT
//public:
//    explicit PicturePreviewPanel(QWidget *parent = nullptr);

//signals:

//};

class QLabel;

enum ShapeType
{
    Rect,//矩形
    Round,//圆形
};

//剪贴图基类 实现了基本的交互功能，并绘制了部分图案，主要的团绘制在子类实现，通过实现paintInit接口
class CutShape : public QWidget
{
public:
    CutShape(QWidget * parent = nullptr);
    ~CutShape();

public:
    QPainterPath CutRegion();

protected:
    //QWidget
    virtual void mousePressEvent(QMouseEvent *) Q_DECL_OVERRIDE;
    virtual void mouseMoveEvent(QMouseEvent *) Q_DECL_OVERRIDE;
    virtual void mouseReleaseEvent(QMouseEvent *) Q_DECL_OVERRIDE;
    virtual void resizeEvent(QResizeEvent *) Q_DECL_OVERRIDE;
    virtual void paintEvent(QPaintEvent *) Q_DECL_OVERRIDE;

    virtual bool paintInit(QPaintEvent *, QPaintDevice *) = 0;
    virtual QPainterPath Region(){ return QPainterPath(); };

protected:
    ShapeType m_Type;
    bool m_MouseDown = false;
    bool m_IsMoving = false;
    bool m_IsFirst = true;
    int border = 5;

private:
    QRect getResizeGem(QRect oldgeo, QPoint mousePoint, bool & ignore);

private:
    bool m_Left = false;
    bool m_Right = false;
    bool m_Bottom = false;
    bool m_Top = false;
    QPoint m_startPoint;
    QPoint m_old_pos;
    QLabel * m_Label;
    QPixmap m_BufferPix;
};

class CutRectangle : public CutShape
{
public:
    CutRectangle(QWidget * parent = nullptr);
    ~CutRectangle();

protected:
    //CutShape
    virtual bool paintInit(QPaintEvent *, QPaintDevice *) Q_DECL_OVERRIDE;
    virtual QPainterPath Region() Q_DECL_OVERRIDE;
};

class CutRound : public CutShape
{
public:
    CutRound(QWidget * parent = nullptr);
    ~CutRound();

protected:
    //CutShape
    virtual bool paintInit(QPaintEvent *, QPaintDevice *) Q_DECL_OVERRIDE;
    virtual QPainterPath Region() Q_DECL_OVERRIDE;

private:
};

class BackgroundWidget : public QWidget
{
public:
    BackgroundWidget(QWidget * parent = nullptr, ShapeType type = Round);
    ~BackgroundWidget();

public:
    void PictureLoadFinished();

protected:
    virtual void paintEvent(QPaintEvent *) Q_DECL_OVERRIDE;

private:
    ShapeType m_Type;
    CutShape * m_CutShape = nullptr;
};


class QPixmap;
class PicturePreviewPanel : public QWidget
{
    Q_OBJECT

public:
    PicturePreviewPanel(QWidget * parent = nullptr);
    ~PicturePreviewPanel();

signals:
    void signGetImage();

public:
    //void LoadPicture(const QString & filepath);//加载图片
    void LoadPicture(QPixmap picture);//加载图片
    void slotSave();

protected:
    virtual bool eventFilter(QObject *, QEvent *) Q_DECL_OVERRIDE;

private:
    void InitializeUI();
    //void LoadPicture_p();

    void LoadPicture_p(QPixmap picture);

private:
    QString m_PicturePath;
    QLabel * m_PictureContainer = nullptr;
    BackgroundWidget * m_BgWidget = nullptr;

    QPixmap picture;
};

#endif // PICTUREPREVIEWPANEL_H
