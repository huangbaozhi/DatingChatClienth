#ifndef QCHATWIDGET_H
#define QCHATWIDGET_H

#include <QWidget>

#include <QTcpSocket>
#include <QHostAddress>
#include <QMessageBox>
#include <QFile>

class QRegisterWidget;
class QListWidget;
class QLineEdit;
class QServerInfo;
class QOperationWidget;
class QSplitter;
class QTextEdit;
class QTextToSpeech;
//class QFile;

class QChatWidget : public QWidget
{
    Q_OBJECT
public:
    explicit QChatWidget(QTcpSocket *socket, QString fri, QString group, QString userName, QWidget *parent = nullptr);

signals:
    void signMyInfo();// 展开个人信息信号
    void signChatUserName();//聊天用户名称

private slots:
    //发送按钮对应的槽函数
    void slotSendButton();
    //连接服务器按钮对应的函数
    void onConnected();
    //和服务器断开连接时执行的槽函数
    void onDisconnected();
    //接收聊天消息的槽函数
    void onReadyRead();
    //网络异常执行的槽函数
    void onError();

    void slotSQLSaveChatRecord();// 数据库保存聊天记录
    void slotViewChatRecord();  // 查看聊天记录

public slots:
     //和服务器连接成功时执行的槽函数
    void slotConnectButton();

    // 语音播报
    void slotSpeech(QString str);

private:
    void initUI();                      // 初始化界面

private:

    bool status;//标识状态：在线/离线
    QTcpSocket tcpSocket;//和服务器通信的套接字
    QHostAddress serverIP;//服务器地址
    quint16 serverPort;//服务器端口
    QString username;//聊天室昵称

    QListWidget* m_pListWidget;
    QTextEdit* m_pSendNewEdit;
    QPushButton* m_pSendBtn;
    QLineEdit* m_pServerIPEdit;
    QLineEdit* m_pServerPortEdit;
    QLineEdit* m_pUserNameEdit;
    QPushButton* m_pConnectButton;

    QServerInfo* m_pServerInfo;

    QString m_sUserName;
    QString m_sUserIP;

    QLabel* m_pUserNameLbl;

    QOperationWidget* m_OperationWidget;// 操作功能

    QString m_sOnLine;

    QSplitter* m_pSplitter;

    QTextToSpeech* m_pTextToSpeech;// 语音播报

    QString m_userName;
};

#endif // QCHATWIDGET_H
