#include "QHeadImage.h"
#include "PicturePreviewPanel.h"

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPushButton>
#include <QFileDialog>
#include <QLabel>

QHeadImage::QHeadImage(QWidget *parent) :  QDialog(parent)
{
    this->setWindowTitle("设置头像");
    iniUI();
}

void QHeadImage::iniUI()
{
    QHBoxLayout* pHMainLayout=new QHBoxLayout(this);
    QVBoxLayout* pMainLayout=new QVBoxLayout(this);

    QString str="QPushButton{font-family:Microsoft Yahei;color:white;background-color:rgb(14 , 150 , 254);border-radius:5px;}\
                QPushButton:hover{background-color:rgb(44 , 137 , 255);border:2px solid rgb(19,34,122);}\
                QPushButton:pressed{background-color:rgb(14 , 135 , 228);padding-left:3px;padding-top:3px;}";

    QHBoxLayout* pBtnLayout=new QHBoxLayout();

    QPushButton* pBtn1=new QPushButton("拍照");
    pBtn1->setFixedSize(70,32);
    pBtn1->setStyleSheet(str);

    QPushButton* pBtn=new QPushButton("选择图片");
    pBtn->setFixedSize(70,32);
    pBtn->setStyleSheet(str);
    connect(pBtn,&QPushButton::clicked,this,&QHeadImage::slotBtn);

    QPushButton* pBtn2=new QPushButton("保存");
    pBtn2->setFixedSize(70,32);
    pBtn2->setStyleSheet(str);
    connect(pBtn2,&QPushButton::clicked,this,&QHeadImage::slotSaveBtn);

    pBtnLayout->addWidget(pBtn1);
    pBtnLayout->addWidget(pBtn);
    pBtnLayout->addWidget(pBtn2);
    pBtnLayout->addStretch();

//    QLabel* pImageViewLbl=new QLabel();
//    QLabel* pImageLbl=new QLabel();

    QWidget* pImageWgt=new QWidget();
    pImageWgt->setFixedSize(432,423);
    QHBoxLayout* pImagelay=new QHBoxLayout();
    QLabel* pImageName=new QLabel("拍摄头显示");
    pImageName->setStyleSheet("QLabel{paddding-left:10px;border:0px;color: #222222;font-family:'Microsoft YaHei';font-size:24px;font-weight: 400;background:transparent;width: 174px;height: 25px;}");

    pImagelay->addStretch();
    pImagelay->addWidget(pImageName);
    pImagelay->addStretch();

    QVBoxLayout* pImageLayout=new QVBoxLayout(pImageWgt);
    pImageLayout->setContentsMargins(QMargins(0,0,0,0));
    pImageLayout->setSpacing(0);
    ImageView_2=new QHBoxLayout();
    image_3=new QLabel();

    //摄像头获取
    m_pCamera = new QCamera(this);
    viewfinder = new QCameraViewfinder(this);
    imageCapture = new QCameraImageCapture(m_pCamera);
    ImageView_2->addWidget(viewfinder);
    image_3->setScaledContents(true);
    m_pCamera->setViewfinder(viewfinder);

    pImageLayout->addLayout(pImagelay);
    pImageLayout->addSpacing(5);
    pImageLayout->addLayout(ImageView_2);
    pImageLayout->addWidget(image_3);

    connect(pBtn1, SIGNAL(clicked()), this, SLOT(captureImage()));
    connect(imageCapture,&QCameraImageCapture::imageSaved,this,&QHeadImage::imageSaved);
    connect(imageCapture, SIGNAL(imageCaptured(int,QImage)), this, SLOT(displayImage(int,QImage)));

    m_pPicturePreviewPanel=new PicturePreviewPanel();
    m_pPicturePreviewPanel->setFixedSize(430,420);
    pMainLayout->addLayout(pBtnLayout);
    pMainLayout->addWidget(m_pPicturePreviewPanel);

    pHMainLayout->addWidget(pImageWgt);
    pHMainLayout->addLayout(pMainLayout);
}

void QHeadImage::slotBtn()
{
    QString filepath = QFileDialog::getOpenFileName(nullptr, QStringLiteral("选择图片"), ".", "*.jpg");

    if (filepath.trimmed().isEmpty() == false)
    {
        m_pPicturePreviewPanel->LoadPicture(filepath);
    }
}

void QHeadImage::slotSaveBtn()
{
    m_pPicturePreviewPanel->slotSave();
    emit signSaveHeadImage();

    m_pCamera->stop();// 关闭摄像头
}

void QHeadImage::captureImage()
{
    imageCapture->capture();
}

void QHeadImage::imageSaved(int id, const QString &fileName)
{
    //处理保存之后的图片
    //1.显示到界面
    image_3->setPixmap(QPixmap(fileName));
    m_pPicturePreviewPanel->LoadPicture(QPixmap(fileName));

}

void QHeadImage::displayImage(int, QImage image)
{
    image_3->setPixmap(QPixmap::fromImage(image));//显示图片
}

void QHeadImage::slotOpenCamera()
{
    m_pCamera->start();
}

