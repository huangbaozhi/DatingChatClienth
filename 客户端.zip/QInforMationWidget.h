#ifndef QINFORMATIONWIDGET_H
#define QINFORMATIONWIDGET_H

#include <QWidget>
#include "QRBaseWidget.h"
#include <QTcpSocket>

class QLineEdit;

class QInforMationWidget : public QRBaseWidget
{
    Q_OBJECT
public:
    explicit QInforMationWidget(QTcpSocket *socket, QString fri, QString group, QString userName, QWidget *parent = nullptr);

public:
    virtual void WriteIni();

public slots:
    void slotGetAccount(QString account);// 获取账号

signals:

private:
    void initUI();// 初始化界面]

private slots:
    void slotModify();// 修改按钮

private:
    QLineEdit* m_pNameEdit;     // 昵称
    QLineEdit* m_pAccoutnEdit;  // 账号
    QLineEdit* m_pIpEdit;       // ip地址
    QLineEdit* m_pPortEdit;     // 端口号
    QLineEdit* m_pFullNameEdit; // 姓名
    QLineEdit* m_pIDEdit;       // 身份证

    QString m_sAccount;

    bool status;

};

#endif // QINFORMATIONWIDGET_H
