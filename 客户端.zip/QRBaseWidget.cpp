﻿#include "QRBaseWidget.h"

QRBaseWidget::QRBaseWidget(QWidget *parent) : QDialog(parent)
{

}

void QRBaseWidget::WriteIni()
{
}
