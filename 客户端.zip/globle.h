#ifndef GLOBLE_H
#define GLOBLE_H
#include <QString>
extern QString removeSpace(QString str);
extern QString dbusername;
extern QString dbpassword;
extern QString dbHostName;
extern QString userLogId;
extern bool isProperId(QString str);
extern bool isProperPassword(QString str);


#endif // GLOBLE_H
