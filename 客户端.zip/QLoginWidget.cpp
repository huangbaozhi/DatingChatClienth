#include "QLoginWidget.h"
#include "QRegisterWidget.h"
#include "QFaceOCR.h"
#include "DatingChatClient.h"
#include "QMovableWindow.h"
#include "globle.h"
#include "QHeadImage.h"

#include <QGraphicsDropShadowEffect>

#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QLabel>

QLoginWidget::QLoginWidget(QWidget *parent) : QDialog(parent)
{
    this->setAttribute(Qt::WA_TranslucentBackground);

    //头像设置
    QHeadImage *pheadImage=new QHeadImage();
    m_pheadImage=pheadImage;

    this->initUI();// 初始化界面

    // 注册界面
    QRegisterWidget* pRegisterWidget=new QRegisterWidget();
    m_pRegisterWidget=pRegisterWidget;

    //创建套接字——云服务器
    socket = new QTcpSocket;
    socket->connectToHost(QHostAddress("122.112.250.76"), 8000);

    connect(socket, &QTcpSocket::connected, this, &QLoginWidget::connect_success);
    connect(socket, &QTcpSocket::readyRead, this, &QLoginWidget::server_reply);
}

// 初始化界面
void QLoginWidget::initUI()
{
    (void)new QMovableWindow(this);

    QWidget* pMainWgt=new QWidget(this);
    pMainWgt->setFixedSize(550,500);
    pMainWgt->setStyleSheet("QWidget{background-color:#ffffff;border: 1px solid #707070;}");

    QHBoxLayout* pMainLayout=new QHBoxLayout(pMainWgt);
    pMainLayout->setMargin(24);
    pMainLayout->setContentsMargins(QMargins(0,0,0,0));
    pMainLayout->setSpacing(0);

    QHBoxLayout* pRegiserLayout=new QHBoxLayout();
    pRegiserLayout->setContentsMargins(QMargins(0,0,0,0));
    pRegiserLayout->setSpacing(0);

    QLabel* pTiteLbl=new QLabel(this);
    pTiteLbl->setText("登录界面");
    pTiteLbl->setStyleSheet("QLabel{border:0px;color: #222222;font-family:'Microsoft YaHei';font-size:24px;font-weight: 400;background:transparent;width: 174px;height: 25px;}");

    pRegiserLayout->addStretch();
    pRegiserLayout->addWidget(pTiteLbl);
    pRegiserLayout->addStretch();


    // 标题栏
    QWidget* pTitleWgt=new QWidget();
    pTitleWgt->setStyleSheet("QWidget{background-color:#55b5ff;border-bottom:0px;}");
    QHBoxLayout* pTitleLyt=new QHBoxLayout(pTitleWgt);
    pTitleLyt->setContentsMargins(QMargins(0,0,0,0));
    pTitleLyt->setSpacing(0);

    // 登录界面
    QString styleSheet = QString("QPushButton{border-image: url(:/botton/nav_window_error_nor_58x40px.png);}\
                                  QPushButton:hover{border-image: url(:/botton/nav_window_error_hover_58x40px.png);}\
                                  QPushButton:pressed{border-image: url(:/botton/nav_window_error_click_58x40px.png);}\
                                  QPushButton{background:transparent;}");

   QString styleMinSheet = QString("QPushButton{border-image: url(:/botton/nav_window_narrow_nor_58x40px.png);}\
                                    PushButton:hover{border-image: url(:/botton/nav_window_narrow_hover_58x40px.png);}\
                                    QPushButton:pressed{border-image: url(:/botton/nav_window_narrow_click_58x40px.png);}\
                                    QPushButton{background:transparent;}");

    QLabel* pTitleLoginLbl=new QLabel();
    pTitleLoginLbl->setFixedSize(30,30);
    pTitleLoginLbl->setStyleSheet("QLabel{border-image:url(:/image/logo_3.png);}");
    QPushButton* pMinBtn=new QPushButton();
    pMinBtn->setFixedSize(58,40);
    pMinBtn->setStyleSheet(styleMinSheet);
    QPushButton* pCloseBtn=new QPushButton();
    pCloseBtn->setFixedSize(58,40);
    pCloseBtn->setStyleSheet(styleSheet);

    connect(pMinBtn,&QPushButton::clicked,this,&QLoginWidget::showMinimized);
    connect(pCloseBtn,&QPushButton::clicked,this,&QLoginWidget::close);

    pTitleLyt->addSpacing(10);
    pTitleLyt->addWidget(pTitleLoginLbl);
    pTitleLyt->addStretch();
    pTitleLyt->addWidget(pMinBtn);
    pTitleLyt->addWidget(pCloseBtn);

    //标题
    QHBoxLayout* pTitleLayout=new QHBoxLayout();
    pTitleLayout->setContentsMargins(QMargins(0,0,0,0));
    QPushButton* pTitleBtn=new QPushButton();
    pTitleBtn->setText("点击设置头像");
    pTitleBtn->setFixedSize(100,42);
    QString sHeadstyle="QPushButton{font-family:Microsoft Yahei;color:white;background-color:rgb(14 , 150 , 254);border-radius:15px;}\
                        QPushButton:hover{background-color:rgb(44 , 137 , 255);border:2px solid rgb(19,34,122);}\
                        QPushButton:pressed{background-color:rgb(14 , 135 , 228);padding-left:3px;padding-top:3px;}";

    pTitleBtn->setStyleSheet(sHeadstyle);

    connect(pTitleBtn,&QPushButton::clicked,this,&QLoginWidget::slotHeadImage);

    pTitleLayout->addStretch();
    pTitleLayout->addWidget(pTitleBtn);
    pTitleLayout->addStretch();

    QVBoxLayout* pVLayout=new QVBoxLayout();
    pVLayout->setSpacing(0);
    pVLayout->setContentsMargins(QMargins(0,0,0,0));

    QString styleEdit="QLineEdit {padding-left:0px;border-top:0px solid;border-bottom:1px solid #0078D4;border-left:0px solid;border-right: 0px solid;}";

    QString sStyleLineEdit = QString("QLineEdit{padding-left:0px;border-top:0px  solid;border-bottom:1px  solid #DFE2E6;border-left:0px solid;border-right: 0px solid;height: 20px;font-size: 16px;font-family: Microsoft YaHei;font-weight: 400;color: #9EA1A6;}\
                              QLineEdit:focus{padding-left:0px;border-top:0px  solid;border-bottom:1px  solid #0078D4;border-left:0px solid;border-right: 0px solid;height: 20px;font-size: 16px;font-family: Microsoft YaHei;font-weight: 400;color: #333333;}\
                              QLineEdit{background:transparent;}");

    // 用户名
    QHBoxLayout* pUserLayout=new QHBoxLayout();
    pUserLayout->setSpacing(0);
    pUserLayout->setContentsMargins(QMargins(0,0,0,0));

    // 账号
    QLabel* pUserLbl=new QLabel();
    pUserLbl->setFixedSize(30,30);
    pUserLbl->setStyleSheet("QLabel{padding-bottom:0px;padding-right:0px;border-image:url(:/image/account.png);}");
    QLineEdit* pUserLineEdit=new QLineEdit();                                                    // 用户名
    m_pUserLineEdit=pUserLineEdit;
    pUserLineEdit->setFixedSize(280,35);
    pUserLineEdit->setStyleSheet(sStyleLineEdit);
    pUserLineEdit->setPlaceholderText("请输入您的账号");

    pUserLayout->addStretch();
    pUserLayout->addWidget(pUserLbl);
    pUserLayout->addSpacing(10);
    pUserLayout->addWidget(pUserLineEdit);
    pUserLayout->addStretch();

    // 密码
    QHBoxLayout* pPwdLayout=new QHBoxLayout();
    pPwdLayout->setSpacing(0);
    pPwdLayout->setContentsMargins(QMargins(0,0,0,0));
    QLabel* pPwdLbl=new QLabel();
    pPwdLbl->setFixedSize(30,30);
    pPwdLbl->setStyleSheet("QLabel{padding-bottom:0px;padding-right:0px;border-image:url(:/image/password.png);}");

    QLineEdit* pPwdLineEdit=new QLineEdit();
    m_pPwdLineEdit=pPwdLineEdit;
    pPwdLineEdit->setEchoMode(QLineEdit::Password); // 密码
    pPwdLineEdit->setFixedSize(280,35);
    pPwdLineEdit->setStyleSheet(sStyleLineEdit);
    pPwdLineEdit->setPlaceholderText("请输入您的密码");

    pPwdLayout->addStretch();
    pPwdLayout->addWidget(pPwdLbl);
    pPwdLayout->addSpacing(10);
    pPwdLayout->addWidget(pPwdLineEdit);
    pPwdLayout->addStretch();

    // 登录
    QString styleBtnSheet = QString("QPushButton{border:0px;background:transparent;font-family:'Microsoft YaHei';font-size:16px;font-weight:Light;color: #0082E6}\
                                     PushButton:hover{color: #0082E6;}\
                                     QPushButton:pressed{color: #0082E6;}\
                                     QPushButton{background:transparent;}");

    QHBoxLayout* pLoginLayout=new QHBoxLayout();
    pLoginLayout->setContentsMargins(QMargins(0,0,0,0));
    pLoginLayout->setSpacing(0);

    QHBoxLayout* pRLayout=new QHBoxLayout();
    pRLayout->setContentsMargins(QMargins(0,0,0,0));
    pRLayout->setSpacing(0);

    QPushButton* pRegisterBtn=new QPushButton();
    pRegisterBtn->setText("本地注册");
    pRegisterBtn->setStyleSheet(styleBtnSheet);
    pRegisterBtn->setFixedSize(70,32);

    QPushButton* pLoginBtn=new QPushButton();
    pLoginBtn->setText("本地登录");
    pLoginBtn->setStyleSheet(styleBtnSheet);
    pLoginBtn->setFixedSize(70,32);

    QHBoxLayout* pRLayout2=new QHBoxLayout();
    pRLayout2->setContentsMargins(QMargins(0,0,0,0));
    pRLayout2->setSpacing(0);

    QPushButton* pRegisterBtn2=new QPushButton();
    pRegisterBtn2->setText("在线注册");
    pRegisterBtn2->setStyleSheet(styleBtnSheet);

    QPushButton* pLoginBtn2=new QPushButton();
    pLoginBtn2->setText("在线登录");
    pLoginBtn2->setStyleSheet(styleBtnSheet);
    pLoginBtn2->setFixedSize(70,32);

    pRLayout->addWidget(pRegisterBtn);
    pRLayout->addSpacing(10);
    pRLayout->addWidget(pRegisterBtn2);

    pRLayout2->addWidget(pLoginBtn);
    pRLayout2->addSpacing(10);
    pRLayout2->addWidget(pLoginBtn2);

    QVBoxLayout* pVlayout=new QVBoxLayout();
    pVlayout->setContentsMargins(QMargins(0,0,0,0));
    pVlayout->setSpacing(0);

    pVlayout->addLayout(pRLayout);
    pVlayout->addLayout(pRLayout2);

    QPushButton* pFaceOCRBtn=new QPushButton();
    pFaceOCRBtn->setText("人脸识别登录");
    pFaceOCRBtn->setStyleSheet(styleBtnSheet);
    pFaceOCRBtn->setFixedSize(120,32);

    pLoginLayout->addStretch();
    pLoginLayout->addLayout(pVlayout);
    pLoginLayout->addSpacing(10);
    pLoginLayout->addWidget(pFaceOCRBtn);
    pLoginLayout->addStretch();


    pVLayout->addWidget(pTitleWgt);
    pVLayout->addSpacing(10);
    pVLayout->addLayout(pRegiserLayout);
    pVLayout->addSpacing(15);
    pVLayout->addLayout(pTitleLayout);
    pVLayout->addSpacing(15);
    pVLayout->addLayout(pUserLayout);
    pVLayout->setSpacing(20);
    pVLayout->addLayout(pPwdLayout);
    pVLayout->setSpacing(20);
    pVLayout->addLayout(pLoginLayout);
    pVLayout->addStretch();

    pMainLayout->addLayout(pVLayout);

    //new消息界面
    m_pDatingChatClient=new DatingChatClient(nullptr,nullptr,nullptr,nullptr);

    connect(pLoginBtn,&QPushButton::clicked,this,&QLoginWidget::slotLogin);                     // 内网登录
    connect(pRegisterBtn,&QPushButton::clicked,this,&QLoginWidget::slotRegister);               // 内网注册
    connect(pRegisterBtn2,&QPushButton::clicked,this,&QLoginWidget::on_registerButton_clicked); // 在线注册
    connect(pLoginBtn2,&QPushButton::clicked,this,&QLoginWidget::on_loginButton_clicked);       // 在线登录
    connect(pFaceOCRBtn,&QPushButton::clicked,this,&QLoginWidget::slotFace);                    // 人脸识别
    connect(this,&QLoginWidget::signLogin,this,&QLoginWidget::slotDatingChatWnd);               // 显示消息界面
    connect(this,&QLoginWidget::signLogin,this,&QLoginWidget::slotClientConnetServer);          // 服务器连接
    connect(this,&QLoginWidget::signLogin,this,&QLoginWidget::GetAccountID);                    // 获取账号id

}

// 登录槽
void QLoginWidget::slotLogin()
{
    QString getId=removeSpace(m_pUserLineEdit->text());
    QString getPass=removeSpace(m_pPwdLineEdit->text());
    qDebug()<<m_pUserLineEdit->text();
    qDebug()<<m_pPwdLineEdit->text();
    if(m_pRegisterWidget->checkadmpassword(getId,getPass) && getId != "")
    {
        userLogId=getId;
        this->hide();
        emit signLogin();// 发送登录成功的信号
    }
    else
    {
        QMessageBox::information(this,"Tip","登陆失败,用户名或者密码错误");
    }
}

// 注册槽
void QLoginWidget::slotRegister()
{
    m_pRegisterWidget->show();//显示注册界面
}

// 人脸识别登录
void QLoginWidget::slotFace()
{
    QFaceOCR *pOrc=new QFaceOCR();
    pOrc->show();

    connect(pOrc,&QFaceOCR::sigFaceSuccess,this,&QLoginWidget::slotLogin);// 人脸识别登录
}

// 聊天界面
void QLoginWidget::slotDatingChatWnd()
{
    this->hide();
    m_pDatingChatClient->show();
}

void QLoginWidget::slotHeadImage()
{
    m_pheadImage->slotOpenCamera();// 打开摄像头
    m_pheadImage->exec();
}

// 连接服务器
void QLoginWidget::slotClientConnetServer()
{
    qDebug()<<"连接服务器成功+++";
    m_pDatingChatClient->slotConnectSever();
}

// 获取账号id
QString QLoginWidget::GetAccountID()
{
    qDebug()<<"userLogId测试测试111"<<userLogId;
    m_pDatingChatClient->slotGetAccountID(userLogId);
}

// 连接服务器
void QLoginWidget::connect_success()
{
    QMessageBox::information(this, "连接提示", "连接服务器成功");
}

void QLoginWidget::on_registerButton_clicked()
{
    QString username = m_pUserLineEdit->text();
    QString password = m_pPwdLineEdit->text();

    QJsonObject obj;
    obj.insert("cmd", "register");
    obj.insert("user", username);
    obj.insert("password", password);

    QByteArray ba = QJsonDocument(obj).toJson();
    socket->write(ba);
}

//服务器回复
void QLoginWidget::server_reply()
{
    QByteArray ba = socket->readAll();//读取服务器回复
    QJsonObject obj = QJsonDocument::fromJson(ba).object();//设置json
    QString cmd = obj.value("cmd").toString();
    if (cmd == "register_reply")
    {
        //用户注册
        client_register_handler(obj.value("result").toString());
    }
    else if (cmd == "login_reply")
    {
        //用户登录
        client_login_handler(obj.value("result").toString(),
                      obj.value("friend").toString(), obj.value("group").toString());// 好友和群
    }
}

//用户注册
void QLoginWidget::client_register_handler(QString res)
{
    if (res == "success")
    {
        QMessageBox::information(this, "注册提示", "注册成功");
    }
    else if (res == "failure")
    {
        QMessageBox::warning(this, "注册提示", "注册失败");
    }
}

// 在线登录
void QLoginWidget::on_loginButton_clicked()
{
    QString username = m_pUserLineEdit->text();
    userName = username;
    QString password = m_pPwdLineEdit->text();

    QJsonObject obj;
    obj.insert("cmd", "login");
    obj.insert("user", username);
    obj.insert("password", password);

    QByteArray ba = QJsonDocument(obj).toJson();
    socket->write(ba);
}

//用户登录
void QLoginWidget::client_login_handler(QString res, QString fri, QString group)
{
    if (res == "user_not_exist")
    {
        QMessageBox::warning(this, "登录提示", "用户不存在");
    }
    else if (res == "password_error")
    {
        QMessageBox::warning(this, "登录提示", "密码错误");
    }
    else if (res == "success")
    {
        this->hide();
        // 结束信号和槽的关系
        socket->disconnect(SIGNAL(readyRead()));
        emit signLoginUserName();// 在线登录成功，发送信号

        // 好友列表——传入socket
        DatingChatClient *c = new DatingChatClient(socket, fri, group, userName);
        m_c=c;
        c->show();
    }
    connect(this,SIGNAL(signLoginUserName()),m_c,SIGNAL(signOnlineUserName()));//登录信号发送给在线信号
}
