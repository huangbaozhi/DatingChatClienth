#ifndef QMYINFOR_H
#define QMYINFOR_H

#include <QWidget>
#include "ConfigIni.h"
#include <QTcpSocket>


class QLabel;
class QRegisterWidget;

class QMyInfor: public QWidget
{

    Q_OBJECT
public:
    explicit QMyInfor(QTcpSocket *socket, QString fri, QString group, QString userName, QWidget *parent = nullptr);

private:
    void initUI();

public slots:
    void slotGetSqlAccount(QString str);// 获取数据库中的账号内容

private:
    QLabel* m_pUserNameLbl;
    QLabel* m_pAccountLbl;
    QLabel* m_pIpLbl;
    QLabel* m_pPortLabel;
    QRegisterWidget* m_pRegisterWidget;
    QString m_str;

    QString m_sUserName;
};

#endif // QMYINFOR_H
