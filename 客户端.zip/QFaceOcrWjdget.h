#ifndef QFACEOCRWJDGET_H
#define QFACEOCRWJDGET_H

#include <QWidget>
#include "QBaiFace.h"

class QCamera;
class QCameraViewfinder;
class QCameraImageCapture;
class QHBoxLayout;
class QPushButton;

class QFaceOcrWjdget : public QWidget
{
    Q_OBJECT
public:
    explicit QFaceOcrWjdget(QWidget *parent = nullptr);

signals:

private:
    void initUI();

private:
    //照相截图
    QCamera *m_pCamera;
    QCameraViewfinder *viewfinder;
    QCameraImageCapture *imageCapture;
    QHBoxLayout* m_pImageView;

    QPushButton* m_pButtonCapture;
};

#endif // QFACEOCRWJDGET_H
