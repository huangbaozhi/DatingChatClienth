﻿#ifndef QREALNAMEAUT_H
#define QREALNAMEAUT_H

#include <QWidget>
#include <QFile>
#include <QFileDialog>
#include "QBaiOCR.h"
#include "QRBaseWidget.h"

class QCAuthenticationWnd;

namespace Ui {
class QRealNameAut;
}

class QRealNameAut : public QRBaseWidget
{
    Q_OBJECT

public:
    explicit QRealNameAut(QWidget *parent = nullptr);
    ~QRealNameAut();

signals:
    void sigBackBtn();       // 返回信号
    void sigIconLbl();       // 显示图标

public slots:
    void slotbackBtn();     // 返回栈窗口的第一页

private slots:
    void on_pushButton_clicked();
    void on_OcrResult(QBaiOCR::OCR_RET ret,QBaiOCR::OCR_TYPE type);
    void on_checkBox_stateChanged(int arg1);

    void on_saveBtn_clicked();
    void on_pushButton_2_clicked();

    void on_backBtn_clicked();

public:
    virtual void WriteIni();

private:
    void OrcBtn();  // 身份识别提交按钮
    void OrcBtn2();  // 身份识别提交按钮

private:
    Ui::QRealNameAut *ui;

    QBaiOCR*     mBaiOCR;

    QCAuthenticationWnd*    m_pAuthenticationWnd;
};

#endif // QREALNAMEAUT_H
