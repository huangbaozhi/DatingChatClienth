#ifndef QHEADIMAGE_H
#define QHEADIMAGE_H

#include <QDialog>

//摄像头部分
#include <QCamera>
#include <QCameraViewfinder>
#include <QCameraImageCapture>
#include <QCameraInfo>
#include <QDebug>
#include <QPixmap>
#include <QLabel>

#include <QHBoxLayout>

class PicturePreviewPanel;

class QHeadImage : public QDialog
{
    Q_OBJECT
public:
    explicit QHeadImage(QWidget *parent = nullptr);

signals:
    void signSaveHeadImage();

    void signImageHead(QPixmap pixmap);

private:
    void iniUI(); // 初始化界面

private slots:
    void slotBtn();
    void slotSaveBtn();

    // 相机
    void captureImage();
    void imageSaved(int id,const QString &fileName);//槽函数
    void displayImage(int,QImage);

public slots:
    void slotOpenCamera();// 打开摄像头

private:
    QWidget* m_pHeadImageWgt;
    PicturePreviewPanel *m_pPicturePreviewPanel;

    //照相截图
    QCamera *m_pCamera;
    QCameraViewfinder *viewfinder;
    QCameraImageCapture *imageCapture;

    QHBoxLayout* ImageView_2;
    QLabel* image_3;
};

#endif // QHEADIMAGE_H
