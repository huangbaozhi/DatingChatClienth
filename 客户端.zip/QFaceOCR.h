#ifndef QFACEOCR_H
#define QFACEOCR_H

#include <QDialog>

#include "QBaiFace.h"
#include <QFile>
#include <QFileDialog>

class QCamera;
class QCameraViewfinder;
class QCameraImageCapture;

namespace Ui {
class QFaceOCR;
}

class QFaceOCR : public QDialog
{
    Q_OBJECT

public:
    explicit QFaceOCR(QWidget *parent = nullptr);
    ~QFaceOCR();

signals:
    void sigFaceSuccess();

private slots:

    void on_FaceResult(QBaiFace::BAI_RET ret);

    // 相机
    void captureImage();
    void imageSaved(int id,const QString &fileName);//槽函数
    void displayImage(int,QImage);


public slots:
    void slotFaceOCR();// 接收到主界面发送的信号，打开摄像头

private:
    Ui::QFaceOCR *ui;


    QBaiFace* mBaiFace;

    //照相截图
    QCamera *m_pCamera;
    QCameraViewfinder *viewfinder;
    QCameraImageCapture *imageCapture;
};

#endif // QFACEOCR_H
