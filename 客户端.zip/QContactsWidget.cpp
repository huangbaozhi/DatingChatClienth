#include "QContactsWidget.h"
#include "chatlist.h"

#include <QVBoxLayout>
#include <QLabel>
#include <QTableWidget>
#include <QStackedWidget>
#include <QListWidget>
#include <QHBoxLayout>
#include <QDebug>
#include <QStringList>
#include <QSqlQuery>
#include <QMessageBox>


QContactsWidget::QContactsWidget(QTcpSocket *socket, QString fri, QString group, QString userName, QWidget *parent)
    : QWidget(parent)
    , m_c(NULL)
{
    //聊天列表
    Chatlist* c= new Chatlist(socket, fri, group, userName);
    m_c=c;

    this->initUI();
}

void QContactsWidget::initUI()
{
    m_pMainLayout=new QHBoxLayout(this);
    m_pMainLayout->addWidget(m_c);
}

// 内网列表页
void QContactsWidget::listPage()
{
    m_pStackedWidget->setCurrentWidget(m_pListWidget);
}

// 在线聊天列表页
void QContactsWidget::chatListPage()
{
    m_pStackedWidget->setCurrentWidget(m_c);
}
