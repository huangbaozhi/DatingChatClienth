﻿#include "QBaiFace.h"

#include <QDebug>
#include <QFile>
#include <QUrlQuery>

QBaiFace::QBaiFace()
{
}
QBaiFace::QBaiFace(QString apiKey, QString secretKey):
    bai_apiKey(apiKey),
    bai_secretKey(secretKey)
{
    manager = new QNetworkAccessManager;// 网络访问管理
    connect(manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(replyFinished(QNetworkReply*)));// 挂起的网络回复完成时，发出此信号

    bai_token = getBai_token(bai_apiKey, bai_secretKey);
    qDebug()<<"Got Access Token: "<<bai_token;
}

QString QBaiFace::getBai_token(QString ApiKey, QString SecretKey)
{
    bai_token.clear();

    QString Url = "http://openapi.baidu.com/oauth/2.0/token?";
    QByteArray append = QString("grant_type=client_credentials&client_id=%1&client_secret=%2&").arg(ApiKey).arg(SecretKey).toLatin1();

    Access_to_http(Url, append);//请求百度服务
    eventLoop.exec();//事件循环等待finish信号的发生，得到数据
    return bai_token;
}

bool QBaiFace::recgFace(QString fpath, quint32 field)
{
    if(fpath.isNull() || fpath.isEmpty()){
        return false;
    }
    face_field = field;
    recgImage("https://aip.baidubce.com/rest/2.0/face/v3/detect", fpath);
    return true;
}

void QBaiFace::recgImage(QString baiUrl, QString fpath)
{
    QFile file(fpath);
    if (!file.open(QIODevice::ReadOnly)||file.size()==0)
    {
        file.close();
        qDebug()<<"Open file failed! imgPath="<<fpath;
        return ;
    }
    QByteArray fdata = file.readAll();
    file.close();

    //配置请求参数
    QUrlQuery params;
    params.addQueryItem("image", fdata.toBase64().toPercentEncoding());// 将一对键值附加到URL的查询字符串的末尾,toBase64返回字符串数组副本，编码为Base64，返回此字节数组的 URI/URL 样式百分比编码副本
    params.addQueryItem("image_type", "BASE64");

    QString field;
    if(face_field & AGE){
        if(field.length()>0)field.append(",");
        field.append("age");
    }
    if(face_field & GENDER){
        if(field.length()>0)field.append(",");
        field.append("gender");
    }

    if(field.length()>0)
    params.addQueryItem("face_field", field);

    QUrl url(baiUrl+"?access_token="+ bai_token);
    QNetworkRequest request(url);
    //设置数据提交格式
    request.setHeader(QNetworkRequest::ContentTypeHeader, QVariant("application/x-www-form-urlencoded;charset=utf-8"));
    manager->post(request, params.toString().toUtf8());
}

void QBaiFace::Access_to_http(QString Url, QByteArray data)
{
    // 构造请求
    QNetworkRequest request((QUrl(Url)));

    //设置头信息
    request.setHeader(QNetworkRequest::ContentTypeHeader, "Content-Type:application/json");
    // 发送请求
    manager->post(request, data);
}

void QBaiFace::replyFinished(QNetworkReply *reply){
    bool isSearchRet = false;

    //反馈数据解析
    int statusCode = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
    if(200 != statusCode)
    {
        qDebug() << "BaiFace::replyFinished: Status code is error:" << statusCode;
        emit baiResult(BAI_ERROR_COMMU);
        return;
    }
    QByteArray replyData = reply->readAll();
    qDebug()<<"BaiFace::replyFinished: reply data = \n"<<QString(replyData);

    QJsonParseError json_error;
    QJsonDocument document = QJsonDocument::fromJson(replyData, &json_error);
    if(json_error.error == QJsonParseError::NoError)
    {
        //判断是否是对象,然后开始解析数据
        QJsonObject rootObj = document.object();
        //因为是预先定义好的JSON数据格式，所以这里可以这样读取
        if(bai_token.isEmpty())
        {
            if(rootObj.contains("access_token")){
                bai_token = rootObj["access_token"].toString();
                qDebug() << "BaiFace::got token="<<bai_token;
            }else{
                bai_token = "error";
                qDebug() << "BaiFace::got token failed!";
            }
            eventLoop.quit();
            return;
        }

        if(rootObj.contains("error_code"))
        {
            if(rootObj["error_code"].toInt()!=0){
                qDebug() << "BaiFace::recg error:" << rootObj["error_msg"].toString();
                emit baiResult(BAI_ERROR_RECG);
                return;
            }
        }

        // 发送识别结果
        if(rootObj.contains("result"))
        {
            if(isSearchRet)emit baiResult(BAI_SUCCESS_SEARCH);
            else emit baiResult(BAI_SUCCESS);

        }else{
            qDebug()<<"BaiFace::replyFinished: error reply data.";
            if(rootObj.contains("error_code")){
                qDebug()<<"BaiFace::replyFinished: error_code = "<<rootObj["error_code"].toInt();
                qDebug()<<"BaiFace::replyFinished: error_msg = "<<rootObj["error_msg"].toString();
            }
            emit baiResult(BAI_ERROR_FORMAT);
        }
    }else{
        qDebug()<<"BaiFace::replyFinished: json parse error.";
        emit baiResult(BAI_ERROR_RECG);
    }
    reply->deleteLater();
}

QBaiFace::FaceInfo& QBaiFace::parseJsonFace(QJsonObject &subObj)
{
    FaceInfo* info = new FaceInfo();
    FaceInfo& f = *info;

    if(subObj.contains("face_token")) f.face_token = subObj["face_token"].toString();
    qDebug()<<"BaiFace::face_token="<<f.face_token;

    // 年龄
    if(subObj.contains("age")) {
        f.age = subObj["age"].toDouble();
        qDebug()<<"BaiFace::age="<<f.age;
    }
    // 性别
    if(subObj.contains("gender")) {
        QJsonObject secObj = subObj["gender"].toObject();
        f.gender.first = secObj["type"].toString();
        f.gender.second = secObj["probability"].toDouble();
        qDebug()<<"BaiFace::expression="<<f.gender;
    }
    return f;
}


