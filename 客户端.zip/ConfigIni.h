#ifndef CONFIGINI_H
#define CONFIGINI_H

#include <QWidget>

class QSettings;

class ConfigIni : public QWidget
{
    Q_OBJECT
public:
    ConfigIni();
    ~ConfigIni();

public:
    void CreateFile();

    void SetNameAndIpIni(QString name,QString ip,QString port);
    void SetAccountIni(QString account);
    void SetRealNameAutIni(QString name,QString id);

    QString GetName();
    QString GetIp();
    QString GetPort();
    QString GetAccount();

    QString GetRealNameAutIni();
    QString GetRealIdAutIni();

signals:

private:
    QString m_FileName;
    QSettings* m_pSetting;
};

#endif // CONFIGINI_H
