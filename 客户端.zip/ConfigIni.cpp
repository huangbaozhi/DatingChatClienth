#include "ConfigIni.h"

#include <QSettings>
#include <QFile>
#include <QDebug>
#include <QCoreApplication>

ConfigIni::ConfigIni()
{
    this->CreateFile();
}

ConfigIni::~ConfigIni()
{
    delete m_pSetting;
    m_pSetting = NULL;
}
// 获取文件路径
void ConfigIni::CreateFile()
{
    m_FileName=QCoreApplication::applicationDirPath()+"/Config.ini";
    qDebug()<<"m_FileName"<<m_FileName;

    //"Config.ini"配置文件，文件存在则打开，不存在则创建
    m_pSetting=new QSettings(m_FileName,QSettings::IniFormat);
}

// 获取昵称
void ConfigIni::SetNameAndIpIni(QString name, QString ip, QString port)
{
    m_pSetting->setValue("/Server/Name",name);
    m_pSetting->setValue("/Server/ip",ip);
    m_pSetting->setValue("/Server/port",port);
}
// 账号
void ConfigIni::SetAccountIni(QString account)
{
    m_pSetting->setValue("/Server/account",account);
}

// 昵称
QString ConfigIni::GetName()
{
    return m_pSetting->value("/Server/Name").toString();
}

// 获取IP地址
QString ConfigIni::GetIp()
{
    return m_pSetting->value("/Server/ip").toString();
}

// 端口号
QString ConfigIni::GetPort()
{
    return m_pSetting->value("/Server/port").toString();
}

QString ConfigIni::GetAccount()
{
    return m_pSetting->value("/Server/account").toString();
}

void ConfigIni::SetRealNameAutIni(QString name,QString id)
{
    m_pSetting->setValue("/OCR/Name",name);
    m_pSetting->setValue("/OCR/ID",id);
}

// 获取实名认证配置
QString ConfigIni::GetRealNameAutIni()
{
    return m_pSetting->value("/OCR/Name").toString();
}

QString ConfigIni::GetRealIdAutIni()
{
    return m_pSetting->value("/OCR/ID").toString();
}
