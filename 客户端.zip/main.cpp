#include "DatingChatClient.h"
#include "QLoginWidget.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QLoginWidget w;
    w.show();
    return a.exec();
}
