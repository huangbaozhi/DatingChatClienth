#include "QMyInfor.h"
#include "globle.h"
#include "QRegisterWidget.h"

#include <QLabel>
#include <QVBoxLayout>
#include <QWidget>
#include <QDebug>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQuery>

QMyInfor::QMyInfor(QTcpSocket *socket, QString fri, QString group, QString userName, QWidget *parent): QWidget(parent)
{
//    m_sUserName=userName;
    qDebug()<<"个人信息界面："<<userName;

    this->initUI();
    this->setStyleSheet("border-left:0px;");

    // 个人信号读取
    if(userName==NULL)
    {
        // 获取配置文件内容
        m_pUserNameLbl->setText(ConfigIni().GetName());
        slotGetSqlAccount(m_str);
        m_pIpLbl->setText(ConfigIni().GetIp());
        m_pPortLabel->setText(ConfigIni().GetPort());
    }
    else
    {
        // 在线登录服务器传入
        m_pUserNameLbl->setText(userName);
        m_pAccountLbl->setText(userName);
        m_pIpLbl->setText("122.112.250.76");
        m_pPortLabel->setText("22");

    }
}

// 初始化界面
void QMyInfor::initUI()
{
    QString style="font-size: 18px;font-family: Microsoft YaHei;font-weight: bold;border: 1px solid #707070;border-left:0px;border-top:0xp;border-bottom:0px;";
    QString style1="font-size: 16px;font-family: Microsoft YaHei;";

    QVBoxLayout* pMainLayout=new QVBoxLayout(this);
    pMainLayout->setContentsMargins(QMargins(0,0,0,0));
    pMainLayout->setSpacing(0);

    QLabel* pLabel=new QLabel("个人信息");
    pLabel->setStyleSheet(style);

    // 用户名
    QHBoxLayout* pNameLayout=new QHBoxLayout();
    QLabel* pNameLbl=new QLabel("用户名：");
    pNameLbl->setStyleSheet(style1);
    QLabel* pUserNameLbl=new QLabel();
    m_pUserNameLbl=pUserNameLbl;
    pUserNameLbl->setStyleSheet(style1);

    pNameLayout->addWidget(pNameLbl);
    pNameLayout->addWidget(pUserNameLbl);
    pNameLayout->addStretch();


    // 账号
    QHBoxLayout* pAccountLayout=new QHBoxLayout();
    QLabel* pAccount=new QLabel("账   号：");
    pAccount->setStyleSheet(style1);
    QLabel* pAccountLbl=new QLabel();// 账号
    m_pAccountLbl=pAccountLbl;
    pAccountLbl->setStyleSheet(style1);

    pAccountLayout->addWidget(pAccount);
    pAccountLayout->addWidget(pAccountLbl);
    pAccountLayout->addStretch();

    // IP地址
    QHBoxLayout* pIpLayout=new QHBoxLayout();
    QLabel* pIp=new QLabel("IP地址：");
    QLabel* pIpLbl=new QLabel();//ip地址
    m_pIpLbl=pIpLbl;
    pIp->setStyleSheet(style1);
    pIpLbl->setStyleSheet(style1);

    pIpLayout->addWidget(pIp);
    pIpLayout->addWidget(pIpLbl);
    pIpLayout->addStretch();

    // 端口号
    QHBoxLayout* pPortLayout=new QHBoxLayout();
    QLabel* pPort=new QLabel("端口号：");
    QLabel* pPortLabel=new QLabel();
    m_pPortLabel=pPortLabel;
    pPort->setStyleSheet(style1);
    pPortLabel->setStyleSheet(style1);

    pPortLayout->addWidget(pPort);
    pPortLayout->addWidget(pPortLabel);
    pPortLayout->addStretch();

    pMainLayout->addWidget(pLabel);
    pMainLayout->addSpacing(20);
    pMainLayout->addLayout(pNameLayout);
    pMainLayout->addSpacing(20);
    pMainLayout->addLayout(pAccountLayout);
    pMainLayout->addSpacing(20);
    pMainLayout->addLayout(pIpLayout);
    pMainLayout->addSpacing(20);
    pMainLayout->addLayout(pPortLayout);
    pMainLayout->addStretch();
}

// 获取数据库中的内容
void QMyInfor::slotGetSqlAccount(QString str)
{
    m_str=str;
    m_pAccountLbl->setText(m_str);
}
