#include "QServerInfo.h"
#include "ConfigIni.h"
#include "QMovableWindow.h"

#include <QPushButton>
#include <QLabel>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QListWidget>
#include <QSplitter>
#include <QStackedWidget>
#include <QListWidget>
#include <QLineEdit>
#include <QTextBrowser>
#include <QDebug>


QServerInfo::QServerInfo(QWidget *parent)
    : QDialog(parent)
{
    this->setFixedSize(550,500);
    this->initUI();
}

QString QServerInfo::GetUserName()
{
    return m_pUserNameEdit->text();
}

void QServerInfo::initUI()
{
    (void)new QMovableWindow(this);
    this->setStyleSheet("QWidget{background-color:#ffffff;border: 1px solid #707070;}");

    QVBoxLayout* pMainLayout=new QVBoxLayout(this);
    pMainLayout->setContentsMargins(QMargins(0,0,0,0));
    pMainLayout->setSpacing(0);

    // 标题栏
    QWidget* pTitleWgt=new QWidget();
    pTitleWgt->setStyleSheet("QWidget{background-color:#55b5ff;border-bottom:0px;}");
    QHBoxLayout* pTitleLyt=new QHBoxLayout(pTitleWgt);
    pTitleLyt->setContentsMargins(QMargins(0,0,0,0));
    pTitleLyt->setSpacing(0);

    // 配置界面
    QString styleSheet = QString("QPushButton{border-image: url(:/botton/nav_window_error_nor_58x40px.png);}\
                                  QPushButton:hover{border-image: url(:/botton/nav_window_error_hover_58x40px.png);}\
                                  QPushButton:pressed{border-image: url(:/botton/nav_window_error_click_58x40px.png);}\
                                  QPushButton{background:transparent;}");

   QString styleMinSheet = QString("QPushButton{border-image: url(:/botton/nav_window_narrow_nor_58x40px.png);}\
                                    PushButton:hover{border-image: url(:/botton/nav_window_narrow_hover_58x40px.png);}\
                                    QPushButton:pressed{border-image: url(:/botton/nav_window_narrow_click_58x40px.png);}\
                                    QPushButton{background:transparent;}");

    QLabel* pTitleLoginLbl=new QLabel();
    pTitleLoginLbl->setFixedSize(39,30);
    pTitleLoginLbl->setStyleSheet("QLabel{border-image:url(:/image/logo_3.png);}");
    QPushButton* pMinBtn=new QPushButton();
    pMinBtn->setFixedSize(58,40);
    pMinBtn->setStyleSheet(styleMinSheet);
    QPushButton* pCloseBtn=new QPushButton();
    pCloseBtn->setFixedSize(58,40);
    pCloseBtn->setStyleSheet(styleSheet);

    connect(pMinBtn,&QPushButton::clicked,this,&QServerInfo::showMinimized);
    connect(pCloseBtn,&QPushButton::clicked,this,&QServerInfo::close);

    pTitleLyt->addSpacing(10);
    pTitleLyt->addWidget(pTitleLoginLbl);
    pTitleLyt->addStretch();
    pTitleLyt->addWidget(pMinBtn);
    pTitleLyt->addWidget(pCloseBtn);

    // 标题
    QHBoxLayout* pInfoLayout=new QHBoxLayout();
    pInfoLayout->setContentsMargins(QMargins(0,0,0,0));
    pInfoLayout->setSpacing(0);

    QLabel* pInfoLbl=new QLabel("配置界面");
    pInfoLbl->setStyleSheet("QLabel{border:0px;color: #222222;font-family:'Microsoft YaHei';font-size:24px;font-weight: 400;background:transparent;width: 174px;height: 25px;}");

    pInfoLayout->addStretch();
    pInfoLayout->addWidget(pInfoLbl);
    pInfoLayout->addStretch();

    QString styleEdit="QLineEdit{border-radius: 2px;border: 1px solid #2E6EE6;;background: #FFFFFF;}";

    QString sStyleLineEdit = QString("QLineEdit{border: 1px solid #EEEEEE;;height: 20px;font-size: 16px;font-family: Microsoft YaHei;font-weight: 400;color: #9EA1A6;}\
                              QLineEdit:focus{border-radius: 2px;border: 1px solid #2E6EE6;;background: #FFFFFF;}\
                              QLineEdit{background:transparent;}");

     QString styleLbl="QLabel{width: 64px;height: 8px;font-size: 16px;font-family: Microsoft YaHei;font-weight: 400;color: #999999;border:0px;}";

     // 聊天室昵称
     QHBoxLayout* pUserLayout=new QHBoxLayout(this);
     QLabel* pUserLbl=new QLabel("昵 称");
     pUserLbl->setStyleSheet(styleLbl);

     QLineEdit* pUserNameEdit=new QLineEdit();
     pUserNameEdit->setFixedSize(280,35);
     m_pUserNameEdit=pUserNameEdit;
     pUserNameEdit->setStyleSheet(sStyleLineEdit);
     pUserNameEdit->setPlaceholderText("您的昵称");

     pUserLayout->addStretch();
     pUserLayout->addWidget(pUserLbl);
     pUserLayout->addSpacing(10);
     pUserLayout->addWidget(pUserNameEdit);
     pUserLayout->addStretch();

    // 服务器地址
    QHBoxLayout* pServerLayout=new QHBoxLayout(this);
    QLabel* pServerLbl=new QLabel("地 址");
    pServerLbl->setStyleSheet(styleLbl);

    QLineEdit* pServerEdit=new QLineEdit(this);
    pServerEdit->setFixedSize(280,35);
    m_pServerEdit=pServerEdit;
    pServerEdit->setStyleSheet(sStyleLineEdit);
    pServerEdit->setPlaceholderText("您的IP地址");

    pServerLayout->addStretch();
    pServerLayout->addWidget(pServerLbl);
    pServerLayout->addSpacing(10);
    pServerLayout->addWidget(pServerEdit);
    pServerLayout->addStretch();

    // 服务器端口
    QHBoxLayout* pPortLayout=new QHBoxLayout(this);
    QLabel* pPortLbl=new QLabel("端 口");
    pPortLbl->setStyleSheet(styleLbl);

    QLineEdit* pPortEdit=new QLineEdit();
    pPortEdit->setFixedSize(280,35);
    m_pPortEdit=pPortEdit;
    pPortEdit->setStyleSheet(sStyleLineEdit);
    pPortEdit->setPlaceholderText("您的端口号");

    pPortLayout->addStretch();
    pPortLayout->addWidget(pPortLbl);
    pPortLayout->addSpacing(10);
    pPortLayout->addWidget(pPortEdit);
    pPortLayout->addStretch();

    QString styleSaveSheet = QString("QPushButton{border: 0px;width: 28px;height: 9px;font-size: 16px;font-family: Microsoft YaHei;font-weight: bold;color: #FFFFFF;border-image: url(:/botton/login_btn_nor_288x48px.png);}\
                                     PushButton:hover{border-image: url(:/botton/login_btn_hover_288x48px.png);}\
                                     QPushButton:pressed{border-image: url(:/botton/login_btn_click_288x48px.png);}\
                                     QPushButton{background:transparent;}");

    // 保存按钮
    QHBoxLayout* pSaveLayout=new QHBoxLayout();
    pSaveLayout->setContentsMargins(QMargins(0,0,0,0));
    pSaveLayout->setSpacing(0);

    QPushButton* pSaveBtn=new QPushButton("保存");
    pSaveBtn->setFixedSize(280,35);
    pSaveBtn->setStyleSheet(styleSaveSheet);

    pSaveLayout->addStretch();
    pSaveLayout->addWidget(pSaveBtn);
    pSaveLayout->addStretch();

    pMainLayout->addWidget(pTitleWgt);
    pMainLayout->addSpacing(30);
    pMainLayout->addLayout(pInfoLayout);
    pMainLayout->addSpacing(30);
    pMainLayout->addLayout(pUserLayout);
    pMainLayout->addSpacing(20);
    pMainLayout->addLayout(pServerLayout);
    pMainLayout->addSpacing(20);
    pMainLayout->addLayout(pPortLayout);
    pMainLayout->addSpacing(20);
    pMainLayout->addLayout(pSaveLayout);
    pMainLayout->addStretch();

    connect(pSaveBtn,&QPushButton::clicked,this,&QServerInfo::WriteIni);
}

//写入配置文件
void QServerInfo::WriteIni()
{
    ConfigIni().SetNameAndIpIni(m_pUserNameEdit->text(),m_pServerEdit->text(),m_pPortEdit->text());

    this->hide();
}

