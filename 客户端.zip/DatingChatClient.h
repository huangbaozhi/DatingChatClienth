#ifndef DATINGCHATCLIENT_H
#define DATINGCHATCLIENT_H

#include <QWidget>

#include <QTcpSocket>
#include <QHostAddress>
#include <QMessageBox>
#include <QPixmap>

class QContactsWidget;
class QNewsWidget;
class QPushButton;
class QStackedWidget;
class QLineEdit;
class QListWidget;
class QTextBrowser;
class QHBoxLayout;
class QSetWidget;
class QLabel;
class QHeadImage;

QT_BEGIN_NAMESPACE
namespace Ui { class DatingChatClient; }
QT_END_NAMESPACE

class DatingChatClient : public QWidget
{
    Q_OBJECT

public:
    DatingChatClient(QTcpSocket *socket, QString fri, QString group, QString userName, QWidget *parent = nullptr);
    ~DatingChatClient();

signals:
    void signServerConnect();//服务器连接信号
    void signOnlineUserName();

public slots:
    void slotConnectSever();// 登录成功连接服务器
    void slotGetAccountID(QString str);// 获取账号

    void displayImage(QPixmap pix);// 设置头像

private:
    void initUI();//初始化界面
    void signAndslot();
    void turnPages();//切换页
    void SQLSaveChatRecord();// 数据库保存聊天记录

private:
    Ui::DatingChatClient *ui;

    QStackedWidget* m_pMiddleStackedWidget;
    QContactsWidget* m_pContactsWidget;// 联系人窗口
    QNewsWidget* m_pNewsWidget;// 聊天界面
    QPushButton* m_pNewsBtn;
    QPushButton* m_pContactsBtn;
    QPushButton* m_pSetBtn;

    QLabel*      m_pHeadLbl;

    QHBoxLayout* m_pMainLayout;
    QSetWidget*  m_pSetWidget;

    QPixmap m_Ppix;

};
#endif // DATINGCHATCLIENT_H
