#ifndef QREGISTERWIDGET_H
#define QREGISTERWIDGET_H

#include <QDialog>

class QLineEdit;
class QListWidget;
class QPushButton;
class QServerInfo;
class QVBoxLayout;

class QRegisterWidget : public  QDialog
{
    Q_OBJECT
public:
    explicit QRegisterWidget(QWidget *parent = nullptr);

public:
    void createdatebase();//创建数据库
    bool checkadmpassword(QString getId,QString getPass);

    void SqlSaveChatRecord();// 保存


signals:

private:
    void initUI();
    void signAndslot();

private slots:
    void slotRegister();
    void slotServer();
    void WriteIni();

private:
    QLineEdit* m_pNameLineEdit;
    QLineEdit* m_pPwdLineEdit;
    QLineEdit* m_pServerEdit;
    QLineEdit* m_pPortEdit;
    QLineEdit* m_pNickNameEdit;

    QLineEdit* m_pUserEdit;

    QPushButton* m_pBtn;

    QServerInfo* m_pServerInfo;
    QVBoxLayout* m_pMainLayout;

};

#endif // QREGISTERWIDGET_H
