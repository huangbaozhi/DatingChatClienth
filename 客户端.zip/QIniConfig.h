﻿#ifndef QINICONFIG_H
#define QINICONFIG_H

#include <QWidget>

class QSettings;

class QIniConfig : public QWidget
{
    Q_OBJECT
public:
    QIniConfig();
    ~QIniConfig();

signals:

public:
    void CreateFile();
    void SetRealNameAutIni(QString name,QString id);

    QString GetRealNameAutIni();
    QString GetRealIdAutIni();

private:
    QString				m_FileName;																					// 文件路径参数
    QSettings*			m_psetting;

};

#endif // QINICONFIG_H
