#ifndef QOPERATIONWIDGET_H
#define QOPERATIONWIDGET_H

#include <QWidget>

class QOperationWidget : public QWidget
{
    Q_OBJECT
public:
    explicit QOperationWidget(QWidget *parent = nullptr);

signals:
    void signSQLChatRecord();// 数据库存储聊天信息

private:
    void initUI();

private slots:
    void slotfileTransfer();                // 文件传输

};

#endif // QOPERATIONWIDGET_H
