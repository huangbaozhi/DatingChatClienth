#include "QChatWidget.h"
#include "ConfigIni.h"
#include "QServerInfo.h"
#include "QOperationWidget.h"
#include "QContactsWidget.h"
#include "clientfile.h"
#include "globle.h"

#include <QLabel>
#include <QHBoxLayout>
#include <QTextBrowser>
#include <QListWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QDebug>
#include <QTextEdit>
#include <QSqlQuery>
#include <QSplitter>
#include <QTextToSpeech>
#include <QDebug>


QChatWidget::QChatWidget(QTcpSocket *socket, QString fri, QString group, QString userName, QWidget *parent)
    : QWidget(parent)
{
    qDebug()<<"用户名"<<userName;
    m_userName=userName;

    // 调用用户信息
    m_pServerInfo=new QServerInfo();

    // 语音播报
    m_pTextToSpeech=new QTextToSpeech();

    status=false;//离线状态
    connect(&tcpSocket,SIGNAL(connected()),this,SLOT(onConnected()));
    connect(&tcpSocket,SIGNAL(disconnected()),this,SLOT(onDisconnected()));
    connect(&tcpSocket,SIGNAL(readyRead()),this,SLOT(onReadyRead()));
    connect(&tcpSocket,SIGNAL(error(QAbstractSocked::SocketError)),
            this,SLOT(onError()));

    this->initUI();

    // 聊天界面用户昵称
    if(userName==NULL)
    {
        // 内网登录
        m_pUserNameLbl->setText(ConfigIni().GetName());
    }
    else
    {
        // 在线登录
        m_pUserNameLbl->setText(m_userName);
    }
}

// 初始化界面
void QChatWidget::initUI()
{
    QWidget* pMainWgt=new QWidget(this);
    pMainWgt->setStyleSheet("background:#f5f5f5;border-left: 1px solid #707070;border: 0px;");
    QVBoxLayout* pMainLayout=new QVBoxLayout(pMainWgt);
    pMainLayout->setContentsMargins(QMargins(0,0,0,0));
    pMainLayout->setSpacing(0);

    QWidget* pLblWgt=new QWidget();
    QHBoxLayout* pLblLayout=new QHBoxLayout(pLblWgt);
    pLblLayout->setContentsMargins(0,0,0,0);
    pLblLayout->setSpacing(0);

    // 获取用户昵称
    QString sName=m_pServerInfo->GetUserName();
    qDebug()<<"sName: "<<sName;

    // 昵称栏
    QWidget* pNameWgt=new QWidget();
    pNameWgt->setFixedHeight(60);
    pNameWgt->setStyleSheet("QWidget{border: 1px solid rgb(231,231,231);}");
    QHBoxLayout* pNameLayout=new QHBoxLayout(pNameWgt);
    pNameLayout->setContentsMargins(QMargins(0,0,0,0));
    pNameLayout->setSpacing(0);

    QLabel* pLabel=new QLabel();
    pLabel->setStyleSheet("QLabel{border-left:0px;border-right:0px;font-size: 18px;font-family: Microsoft YaHei;font-weight: 400}");
    m_pUserNameLbl=pLabel;

    QPushButton* pMoreBtn=new QPushButton();
    pMoreBtn->setFixedSize(30,30);
    pMoreBtn->setStyleSheet("border-left:0px;border-top:0px;border-bottom:0px;image:url(:/botton/moreBtn.png)");

    connect(pMoreBtn,&QPushButton::clicked,this,&QChatWidget::signMyInfo);

    pNameLayout->addWidget(pLabel);
    pNameLayout->addStretch();
    pNameLayout->addWidget(pMoreBtn);

    // 聊天列表
    m_pListWidget=new QListWidget();
    m_pListWidget->setFixedSize(580,460);
    m_pListWidget->setStyleSheet("border-right:1px solid rgb(231,231,231)");

    // 发送聊天框
    QWidget* pChatWgt=new QWidget();
    pChatWgt->setStyleSheet("QWidget{border-top:0px;border-right:1px solid rgb(231,231,231);}");
    QHBoxLayout* pChatLayout=new QHBoxLayout(pChatWgt);
    pChatLayout->setContentsMargins(QMargins(0,0,0,0));
    pChatLayout->setSpacing(0);

    // 操作内容(截图、文件、聊天内容）
    m_OperationWidget=new QOperationWidget();

    // 消息界面
    QString styleEdit="QTextEdit{padding-top:0px;background:#f5f5f5;border:0px;}";

    m_pSendNewEdit=new QTextEdit();
    m_pSendNewEdit->setFixedHeight(100);
    m_pSendNewEdit->setStyleSheet(styleEdit);

    QString styleBtnSheet1 = QString("QPushButton{border:0px;background: #0078D4;font-size: 16px;border-radius: 15px;font-family: Microsoft YaHei;font-weight: bold;color: #FFFFFF;}\
                                     PushButton:hover{color: #0082E6;}\
                                     QPushButton:pressed{color: #0078D4;}\
                                     QPushButton{background:#0078D4;}");

    m_pSendBtn=new QPushButton("发送");
    m_pSendBtn->setFixedSize(70,32);
    m_pSendBtn->setStyleSheet(styleBtnSheet1);

    // 连接服务器
    m_pConnectButton=new QPushButton("连接服务器");
    m_pConnectButton->setVisible(false);

    pChatLayout->addWidget(m_pSendNewEdit);
    pChatLayout->addSpacing(20);
    pChatLayout->addWidget(m_pSendBtn);
    pChatLayout->addSpacing(20);

    QWidget* pVWgt=new QWidget();
    pVWgt->setStyleSheet("QWidget{border:1px solid #e5e5e5;border-bottom:0px;border-left:0px;}");
    pVWgt->setFixedHeight(200);
    QVBoxLayout* pVLayout=new QVBoxLayout(pVWgt);
    pVLayout->setContentsMargins(QMargins(0,0,0,0));
    pVLayout->setSpacing(0);

    pVLayout->addWidget(m_OperationWidget);
    pVLayout->addWidget(pChatWgt);
    pVLayout->addStretch();

    pMainLayout->addWidget(pNameWgt);
    pMainLayout->addWidget(m_pListWidget);
    pMainLayout->addWidget(pVWgt);
    pMainLayout->addSpacing(20);

    connect(m_pSendBtn,&QPushButton::clicked,this,&QChatWidget::slotSendButton);//发送消息
    connect(m_pConnectButton,&QPushButton::clicked,this,&QChatWidget::slotConnectButton);//连接服务器
    connect(m_OperationWidget,&QOperationWidget::signSQLChatRecord,this,&QChatWidget::slotSQLSaveChatRecord);//消息聊天记录
}

// 发送按钮对应的槽函数
void QChatWidget::slotSendButton()
{
    //获取用户输入聊天消息
    QString msg=m_pSendNewEdit->toPlainText();
    if(msg=="")
    {
        return;
    }
    msg=username+":"+msg;
    //发送聊天消息
    tcpSocket.write(msg.toUtf8());
    //清空消息输入框
    m_pSendNewEdit->clear();
}

void QChatWidget::slotConnectButton()
{

    status==false;
    //获取服务器IP
    serverIP.setAddress(ConfigIni().GetIp());

    //获取服务器端口
    serverPort=ConfigIni().GetPort().toShort();
    //获取聊天室昵称
    username=ConfigIni().GetName();

    //向服务器发送请求
    //成功发送信号：connected
    //失败发送信号：error
    tcpSocket.connectToHost(serverIP,serverPort);
}

// 语音播报
void QChatWidget::slotSpeech(QString str)
{
    if(m_pTextToSpeech->state()==QTextToSpeech::Ready)
    {
        m_pTextToSpeech->say(str);
    }
}

void QChatWidget::onConnected()
{
    status=true;//在线
    m_pSendBtn->setEnabled(true);//恢复按钮状态
    m_pConnectButton->setText("离线");

    //向服务器发送进入聊天室提示消息
    QString msg=username+":在线";
    tcpSocket.write(msg.toUtf8());
}

void QChatWidget::onDisconnected()
{
    status=false;//离开线
    m_pConnectButton->setText("连接服务器");
}

void QChatWidget::onReadyRead()
{
    if(tcpSocket.bytesAvailable())
    {
        QByteArray buf=tcpSocket.readAll();
        //显示消息
        m_pListWidget->addItem(buf);
        m_sOnLine=m_pListWidget->trUtf8(buf);
        QStringList sList;
        sList<<m_sOnLine;

        qDebug()<<"显示消息：==="<<sList;

        // 语音播报

        // 获取在线人数列表
        m_sOnLine=m_pListWidget->trUtf8(buf);
        qDebug()<<"sOnLine--"<<m_sOnLine;
        m_pListWidget->scrollToBottom();
    }

}

void QChatWidget::onError()
{
    //errorString()：获取网络异常的原因
    QMessageBox::critical(this,"ERROR",tcpSocket.errorString());
}

void QChatWidget::slotSQLSaveChatRecord()
{
    qDebug()<<"保存聊天记录";
    for(int i;i<m_pListWidget->count();i++)
    {

        QString itemText = m_pListWidget->item(i)->text();


        QSqlQuery query;
        query.prepare("insert into chatRecordtable (chatRecord) "
                      "values(?)");
        query.addBindValue(itemText);

        qDebug()<<"数据库存储：==="<<itemText;
        bool r=query.exec();
        if(!r)
        {
              QMessageBox::critical(this,"错误","插入失败！");// 在指定的父小部件前面打开一个具有给定标题和文本的关键消息框
        }
        else
        {
              QMessageBox::information(this,"消息","插入成功");
               //this->hide();
        }
    }
}

// 查看聊天记录
void QChatWidget::slotViewChatRecord()
{
    QString getChatRecord;
    qDebug()<<"聊天记录——测试===="<<getChatRecord;

    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setHostName(dbHostName);       //选择本地主机
    db.setDatabaseName("db2.db");     //设置数据源名称
    db.setUserName(dbusername);       //登录用户
    db.setPassword(dbpassword);       //密码
    bool isOpen=db.open();
    if(isOpen)
    {
        QSqlQuery query(db);

        query.exec("select chatRecord from chatRecordtable='"+getChatRecord+"'");
        query.next();//检索结果中的下一条记录，并将查询定位在检索到的记录上
    }

}






