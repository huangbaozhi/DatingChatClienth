﻿#ifndef QBAIOCR_H
#define QBAIOCR_H

#include <QObject>
#include <QUrl> // QUrl类为处理URL提供了一个方便的接口

#include <QNetworkAccessManager>// QNetworkAccessManager类允许应用程序发送网络请求和接收回复
#include <QNetworkReply>// 包含使用QNetworkAccessManager发送的请求的数据和标头
#include <QByteArray>// 提供一个字节数组
#include <QEventLoop>// 提供了一种进入和离开事件循环的方法
#include <QJsonObject>// 封装了一个JSON对象
#include <QJsonArray>// 封装了一个JSON数组
#include <QJsonDocument>// 提供了一种读取和写入JSON文档的方法

class QBaiOCR : public QObject
{
    Q_OBJECT
public:

    enum OCR_RET
    {
        OCR_SUCCESS,
        OCR_ERROR,
        OCR_ERROR_RECG,             //识别错误
        OCR_ERROR_NOTHING,          //没有要识别的信息
        OCR_ERROR_IMG,
        OCR_ERROR_PARAM,            //参数错误
        OCR_ERROR_BUSY,             //繁忙
        OCR_ERROR_COMMU,            //通信错误
        OCR_ERROR_TIMEOUT,          //执行超时
        OCR_ERROR_OTHER,            //其余错误
    };
    Q_ENUM(OCR_RET)

    //识别证件类型
    enum OCR_TYPE
    {
        OCR_UNKNOWN_TYPE,
        OCR_ID_CARD,//身份证
    };
    Q_ENUM(OCR_TYPE)

    //身份证识别结果
    class IdCard{
    public:
        QString address;//住址
        QString id;//身份证号
        QString birth;//生日
        QString name;//姓名
        QString gender;//性别
        QString nation;//民族
        QString organization;//签发机关
        QString term;//有效期限
        IdCard() {}

        // 名字
        QString toString(){
            QString str = "";
            str += name;
            return str;
        }
        // 身份证号
        QString toStringID(){
            QString str = "";
            str += id;
            return str;
        }
        // 国徽面
        QString toStringNational(){
            QString str = "";
            str += organization;// 签发机关
            str += term; // 有效期限
            return str;
            };

        void clear()
        {
            name.clear();
            id.clear();

        }
    };

    // 构造函数
    QBaiOCR();
    QBaiOCR(QString apiKey, QString secretKey);

    //获取识别结果的函数
    IdCard* getIdCard() const;

private:
    QString bai_apiKey, bai_secretKey, bai_token;
    QNetworkAccessManager *manager;
    QNetworkReply *pReplay;
    QString  data[10];

    void Access_to_http(QString Url, QByteArray data);
    QString getBaiOCR_token(QString ApiKey, QString SecretKey);

    OCR_TYPE mOcrType;//识别类型
    IdCard mIdCard;//保存身份证结果

    //解析百度ai返回结果函数
    bool parseJsonIdCard(QJsonObject& subObj);//解析身份证识别返回结果

signals:
    void httpFinish(QByteArray);
    void ocrResult(OCR_RET ret,OCR_TYPE mOcrType);

public slots:
    bool recgIdCard(QString fpath);
    void recgImage(QString baiUrl, QString fpath);

private slots:
    void getHttpComReply(QNetworkReply *pReplay);
    void replyFinished(QNetworkReply *reply);
};

#endif // QBAIOCR_H
