#include "QFaceOCR.h"
#include "ui_QFaceOCR.h"

//摄像头部分
#include <QCamera>
#include <QCameraViewfinder>
#include <QCameraImageCapture>
#include <QCameraInfo>
#include <QDebug>
#include <QPixmap>

QFaceOCR::QFaceOCR(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::QFaceOCR)
{
    ui->setupUi(this);

    this->setWindowTitle("人脸识别登录");

    QString apiKey = "eZDbU4LegAtD4ScxTnxe5wsz";
    QString secretKey = "wvwgLyUwdbMwwGEO8u5EtAibF934OeSt";
    mBaiFace = new QBaiFace(apiKey,secretKey);
    connect(mBaiFace,&QBaiFace::baiResult,this,&QFaceOCR::on_FaceResult);

    //摄像头获取
    m_pCamera = new QCamera(this);
    viewfinder = new QCameraViewfinder(this);
    imageCapture = new QCameraImageCapture(m_pCamera);
    ui->ImageView_2->addWidget(viewfinder);
    ui->image_3->setScaledContents(true);
    m_pCamera->setViewfinder(viewfinder);

    slotFaceOCR();

    connect(ui->buttonCapture, SIGNAL(clicked()), this, SLOT(captureImage()));
    connect(imageCapture,&QCameraImageCapture::imageSaved,this,&QFaceOCR::imageSaved);
    connect(imageCapture, SIGNAL(imageCaptured(int,QImage)), this, SLOT(displayImage(int,QImage)));
}

QFaceOCR::~QFaceOCR()
{
    delete ui;
}

void QFaceOCR::captureImage()
{
    imageCapture->capture();
}

void QFaceOCR::imageSaved(int id, const QString &fileName)
{
    qDebug()<<"QFaceOCR::imageSaved:"<<fileName;
    //处理保存之后的图片
    //1.显示到界面
    ui->image_3->setPixmap(QPixmap(fileName));
    //2.进行百度ai的识别
    mBaiFace->recgFace(fileName,QBaiFace::AGE|QBaiFace::GENDER|QBaiFace::GENDER);

}

void QFaceOCR::displayImage(int, QImage image)
{
    ui->image_3->setPixmap(QPixmap::fromImage(image));//显示图片
}

void QFaceOCR::slotFaceOCR()
{
    m_pCamera->start();
}

//识别结果的槽函数
void QFaceOCR::on_FaceResult(QBaiFace::BAI_RET ret)
{
    QString msg;
    if(ret == QBaiFace::BAI_SUCCESS)
    {
        msg.append("识别成功");
        emit sigFaceSuccess();
        m_pCamera->stop();// 关闭摄像头
        this->hide();
    }
    else
    {
        msg.append("识别失败");
    }
    ui->label_4->setText(msg);
}

