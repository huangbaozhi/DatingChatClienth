#ifndef QNEWSWIDGET_H
#define QNEWSWIDGET_H

#include <QWidget>
#include <QTcpSocket>

class QToolButton;
class QStackedWidget;
class QChatWidget;
class QVBoxLayout;
class QSplitter;
class QMyInfor;

class QNewsWidget : public QWidget
{
    Q_OBJECT
public:
    explicit QNewsWidget(QTcpSocket *socket, QString fri, QString group, QString userName, QWidget *parent = nullptr);

signals:
    void signNewUserName();//用户名

private:
    void initUI();//初始化界面

public slots:
    void slotServer();//服务器槽
    void slotMyInfo(QString str);//个人信息槽

private:
    QVector<QToolButton*> m_vector;
    QStackedWidget* m_pChatStackedWidget;
    QChatWidget* m_pChatWidgt;
    QVBoxLayout* m_pMiddleLayout;
    QMyInfor* m_pMyInfor;

    QSplitter*   m_pSplitter;
    QWidget*     m_pMiddleWgt;
};

#endif // QNEWSWIDGET_H
