#include "QSetWidget.h"
#include "QRealNameAut.h"
#include "SwitchButton.h"
#include "globle.h"
#include "QInforMationWidget.h"

#include <QPushButton>
#include <QVBoxLayout>
#include <QStackedWidget>
#include <QDebug>
#include <QLabel>
#include <QHBoxLayout>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlRecord>
#include <QStackedWidget>
#include <QSplitter>
#include <QListWidget>

QSetWidget::QSetWidget(QTcpSocket *socket, QString fri, QString group, QString userName, QWidget *parent) : QWidget(parent)
{
    this->setStyleSheet("QWidget{background:#f5f5f5;}");

    m_pInforMationWidget=new QInforMationWidget(socket, fri, group, userName);

    this->initUI();
}

// 初始化界面
void QSetWidget::initUI()
{
    QString styleBtn="font-size: 16px;font-family: Microsoft YaHei;font-weight: bold;color: #222222;";

    QString styleBtnSheet1 = QString("QPushButton{border:0px;background: #0078D4;font-size: 16px;border-radius: 15px;font-family: Microsoft YaHei;font-weight: bold;color: #FFFFFF;}\
                                     PushButton:hover{color: #0082E6;}\
                                     QPushButton:pressed{color: #0078D4;}\
                                     QPushButton{background:#0078D4;}");

    // 主布局
    QHBoxLayout* pHMainLayout=new QHBoxLayout(this);
    QSplitter* pSplitter=new QSplitter();
    pSplitter->setStyleSheet("QSplitter::handle { background-color:rgb(231,231,231); }"); //设置分界线的样式
    pSplitter->setHandleWidth(1);

    QWidget* pVMainWgt=new QWidget();
    QVBoxLayout* pMainLayout=new QVBoxLayout(pVMainWgt);

    // 聊天记录
    QHBoxLayout* pHChatRecordLayout=new QHBoxLayout();
    pHChatRecordLayout->setContentsMargins(QMargins(0,0,0,0));
    pHChatRecordLayout->setSpacing(0);

    QLabel* pChatRecordLbl=new QLabel("聊天记录：");
    pChatRecordLbl->setStyleSheet(styleBtn);
    QPushButton* pChatRecordBtn=new QPushButton("打开");
    m_pChatRecordBtn=pChatRecordBtn;
    pChatRecordBtn->setFixedSize(70,32);
    pChatRecordBtn->setStyleSheet(styleBtnSheet1);
    connect(pChatRecordBtn,&QPushButton::clicked,this,&QSetWidget::slotViewChatRecord);

    pHChatRecordLayout->addWidget(pChatRecordLbl);
    pHChatRecordLayout->addSpacing(10);
    pHChatRecordLayout->addWidget(pChatRecordBtn);
    pHChatRecordLayout->addStretch();

    // 布局
    QHBoxLayout* pVoiceLayout=new QHBoxLayout();
    pVoiceLayout->setContentsMargins(QMargins(0,0,0,0));
    pVoiceLayout->setSpacing(0);

    // 语音提示
    QHBoxLayout* pHVoiceLayout=new QHBoxLayout();
    pHVoiceLayout->setContentsMargins(QMargins(0,0,0,0));
    pHVoiceLayout->setSpacing(0);

    QLabel* pVoiceLbl=new QLabel("语音提示：");
    pVoiceLbl->setStyleSheet(styleBtn);
    QPushButton* pVoiceBtn=new QPushButton("打开");
    pVoiceBtn->setFixedSize(70,32);
    pVoiceBtn->setStyleSheet(styleBtnSheet1);

    // 滑动按钮
    SwitchButton* pSwitchBtn=new SwitchButton();
    pSwitchBtn->setFixedSize(70,32);
    connect(pSwitchBtn,&SwitchButton::signalON,this,&QSetWidget::slotSwicthON);
    connect(pSwitchBtn,&SwitchButton::signalOFF,this,&QSetWidget::slotSwicthOFF);

    pHVoiceLayout->addWidget(pVoiceLbl);
    pHVoiceLayout->addSpacing(10);
    pHVoiceLayout->addWidget(pSwitchBtn);
    pHVoiceLayout->addStretch();

    // 个人认证
    QHBoxLayout* pHPersonalLayout=new QHBoxLayout();
    pHPersonalLayout->setContentsMargins(QMargins(0,0,0,0));
    pHPersonalLayout->setSpacing(0);

    QLabel* pPersonalLbl=new QLabel("个人认证：");
    pPersonalLbl->setStyleSheet(styleBtn);
    QPushButton* pPersonalBtn=new QPushButton("打开");
    pPersonalBtn->setFixedSize(70,32);
    pPersonalBtn->setStyleSheet(styleBtnSheet1);
    connect(pPersonalBtn,&QPushButton::clicked,this,&QSetWidget::slotRealNameAud);

    pHPersonalLayout->addWidget(pPersonalLbl);
    pHPersonalLayout->addSpacing(10);
    pHPersonalLayout->addWidget(pPersonalBtn);
    pHPersonalLayout->addStretch();

    // 详细信息
    QHBoxLayout* pDetailsLayout=new QHBoxLayout();
    pDetailsLayout->setContentsMargins(QMargins(0,0,0,0));
    pDetailsLayout->setSpacing(0);

    QLabel* pDetailsLbl=new QLabel("详细信息：");
    pDetailsLbl->setStyleSheet(styleBtn);
    QPushButton* pDetailsBtn=new QPushButton("打开");
    m_pDetailsBtn=pDetailsBtn;
    pDetailsBtn->setFixedSize(70,32);
    pDetailsBtn->setStyleSheet(styleBtnSheet1);

    pDetailsLayout->addWidget(pDetailsLbl);
    pDetailsLayout->addSpacing(10);
    pDetailsLayout->addWidget(pDetailsBtn);
    pDetailsLayout->addStretch();

    pMainLayout->addSpacing(10);
    pMainLayout->addLayout(pHChatRecordLayout);
    pMainLayout->addSpacing(10);
    pMainLayout->addLayout(pHVoiceLayout);
    pMainLayout->addSpacing(10);
    pMainLayout->addLayout(pHPersonalLayout);
    pMainLayout->addSpacing(10);
    pMainLayout->addLayout(pDetailsLayout);
    pMainLayout->addStretch();

    QStackedWidget* pStackedWidget=new QStackedWidget(this);
    m_pStackedWidget=pStackedWidget;
    m_pListWidget=new QListWidget(this);
    pStackedWidget->addWidget(m_pListWidget);

    // 个人详细信息添加到栈页面
    pStackedWidget->addWidget(m_pInforMationWidget);

    pSplitter->addWidget(pVMainWgt);
    pSplitter->addWidget(pStackedWidget);

    pHMainLayout->addWidget(pSplitter);

    connect(pChatRecordBtn,&QPushButton::clicked, this, &QSetWidget::turnPages);
    connect(m_pDetailsBtn,&QPushButton::clicked, this, &QSetWidget::turnPages);
}

// 个人认证槽
void QSetWidget::slotRealNameAud()
{
//    QRealNameAut *realNameAut=new QRealNameAut();
//    realNameAut->show();
    QRealNameAut realNameAut;
    realNameAut.exec();
}

// 开启
void QSetWidget::slotSwicthON()
{
    qDebug()<<"语音播报开启！";
    emit signSwicthON();
}

// 关闭
void QSetWidget::slotSwicthOFF()
{
    qDebug()<<"语音播报关闭！";
    emit signSwicthOFF();
}

void QSetWidget::slotGetAccount(QString account)
{
    m_pInforMationWidget->slotGetAccount(account);
}


// 查看聊天记录
void QSetWidget::slotViewChatRecord()
{
    QString getChatRecord;
    qDebug()<<"聊天记录——测试===="<<getChatRecord;

    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setHostName(dbHostName);       //选择本地主机
    db.setDatabaseName("db2.db");     //设置数据源名称
    db.setUserName(dbusername);       //登录用户
    db.setPassword(dbpassword);       //密码
    bool isOpen=db.open();
    if(isOpen)
    {
        QSqlQuery query(db);

        query.exec("select chatRecord from chatRecordtable");
        query.next();//检索结果中的下一条记录，并将查询定位在检索到的记录上

        qDebug()<<"聊天记录——测试111===="<<getChatRecord;

        query.prepare("select * from chatRecordtable");  //查询数据库中所有数据
        query.exec();
        QSqlRecord rec = query.record();
        while(query.next())
        {
    //        rec = query.record();
            int snamecol = rec.indexOf("chatRecord");
            QString value = query.value(snamecol).toString();
            m_pListWidget->addItem(value);
            qDebug()<<"测试Test==="<<value;
        }

    }
}

// 翻页
void QSetWidget::turnPages()
{
    QPushButton* pBtn=dynamic_cast<QPushButton*>(QObject::sender());
    if(!pBtn) return;

    if(pBtn==m_pChatRecordBtn&&m_pListWidget)
    {
        m_pStackedWidget->setCurrentWidget(m_pListWidget);
    }
    else if(pBtn==m_pDetailsBtn&&m_pInforMationWidget)
    {
        m_pStackedWidget->setCurrentWidget(m_pInforMationWidget);
    }
}
