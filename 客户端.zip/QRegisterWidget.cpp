#include "QRegisterWidget.h"
#include "QServerInfo.h"
#include "ConfigIni.h"
#include "QMovableWindow.h"
#include "globle.h"

#include <QFileInfo>
#include <QSqlDatabase>// 处理与数据库的连接
#include <QSqlQuery>// 执行和操作QSL语句方法
#include <QDebug>
#include <QMessageBox>

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QSqlQuery>
#include <QMessageBox>
#include <QListWidget>
#include <QStackedWidget>


QRegisterWidget::QRegisterWidget(QWidget *parent)
    :  QDialog(parent)
{
    this->initUI();// 初始化界面

    // 创建数据库
    this->createdatebase();

    QServerInfo* pServerInfo=new QServerInfo();
    m_pServerInfo=pServerInfo;
}

void QRegisterWidget::initUI()
{
    this->setStyleSheet("QWidget{background-color:#ffffff;border: 1px solid #707070;}");
    (void)new QMovableWindow(this);

    this->setFixedSize(550,500);

    QVBoxLayout* pMainLayout=new QVBoxLayout(this);
    m_pMainLayout=pMainLayout;
    pMainLayout->setContentsMargins(QMargins(0,0,0,0));
    pMainLayout->setSpacing(0);

    // 标题栏
    QWidget* pTitleWgt=new QWidget();
    pTitleWgt->setStyleSheet("QWidget{background-color:#55b5ff;border-bottom:0px;}");
    QHBoxLayout* pTitleLyt=new QHBoxLayout(pTitleWgt);
    pTitleLyt->setContentsMargins(QMargins(0,0,0,0));
    pTitleLyt->setSpacing(0);

    QString styleSheet = QString("QPushButton{border-image: url(:/botton/nav_window_error_nor_58x40px.png);}\
                                  QPushButton:hover{border-image: url(:/botton/nav_window_error_hover_58x40px.png);}\
                                  QPushButton:pressed{border-image: url(:/botton/nav_window_error_click_58x40px.png);}\
                                  QPushButton{background:transparent;}");

   QString styleMinSheet = QString("QPushButton{border-image: url(:/botton/nav_window_narrow_nor_58x40px.png);}\
                                    PushButton:hover{border-image: url(:/botton/nav_window_narrow_hover_58x40px.png);}\
                                    QPushButton:pressed{border-image: url(:/botton/nav_window_narrow_click_58x40px.png);}\
                                    QPushButton{background:transparent;}");

    QLabel* pTitleLoginLbl=new QLabel();
    pTitleLoginLbl->setFixedSize(39,30);
    pTitleLoginLbl->setStyleSheet("QLabel{border-image:url(:/image/logo_3.png);}");
    QPushButton* pMinBtn=new QPushButton();
    pMinBtn->setFixedSize(58,40);
    pMinBtn->setStyleSheet(styleMinSheet);
    QPushButton* pCloseBtn=new QPushButton();
    pCloseBtn->setFixedSize(58,40);
    pCloseBtn->setStyleSheet(styleSheet);

    pTitleLyt->addSpacing(10);
    pTitleLyt->addWidget(pTitleLoginLbl);
    pTitleLyt->addStretch();
    pTitleLyt->addWidget(pMinBtn);
    pTitleLyt->addWidget(pCloseBtn);

    connect(pMinBtn,&QPushButton::clicked,this,&QRegisterWidget::showMinimized);
    connect(pCloseBtn,&QPushButton::clicked,this,&QRegisterWidget::close);


    QHBoxLayout* pRegiserLayout=new QHBoxLayout();
    pRegiserLayout->setContentsMargins(QMargins(0,0,0,0));
    pRegiserLayout->setSpacing(0);

    QLabel* pTiteLbl=new QLabel(this);
    pTiteLbl->setText("注册界面");
    pTiteLbl->setStyleSheet("QLabel{border:0px;color: #222222;font-family:'Microsoft YaHei';font-size:24px;font-weight: 400;background:transparent;width: 174px;height: 25px;}");

    pRegiserLayout->addStretch();
    pRegiserLayout->addWidget(pTiteLbl);
    pRegiserLayout->addStretch();



    QString styleLbl="QLabel{width: 64px;height: 8px;font-size: 16px;font-family: Microsoft YaHei;font-weight: 400;color: #999999;border:0px;}";

    QString sStyleLineEdit = QString("QLineEdit{border: 1px solid #EEEEEE;;font-size: 16px;font-family: Microsoft YaHei;font-weight: 400;color: #9EA1A6;}\
                              QLineEdit:focus{border-radius: 2px;border: 1px solid #2E6EE6;background: #FFFFFF;color: #333333;}}\
                              QLineEdit{background:transparent;}");

    // 用户名
    QHBoxLayout* pNicknameLayout=new QHBoxLayout();
    pNicknameLayout->setContentsMargins(QMargins(0,0,0,0));
    pNicknameLayout->setSpacing(0);


    QLabel* pNickNameLbl=new QLabel("昵 称");
    pNickNameLbl->setStyleSheet(styleLbl);


    QLineEdit* pNickNameEdit=new QLineEdit();
    m_pNickNameEdit=pNickNameEdit;
    pNickNameEdit->setFixedSize(280,35);
    pNickNameEdit->setStyleSheet(sStyleLineEdit);

    pNicknameLayout->addStretch();
    pNicknameLayout->addWidget(pNickNameLbl);
    pNicknameLayout->addSpacing(10);
    pNicknameLayout->addWidget(pNickNameEdit);
    pNicknameLayout->addStretch();

    QHBoxLayout* pNameLayout=new QHBoxLayout(this);
    QLabel* pNameLbl=new QLabel(this);
    pNameLbl->setText("账 号");
    pNameLbl->setStyleSheet(styleLbl);

    QLineEdit* pNameLineEdit=new QLineEdit(this);
    m_pNameLineEdit=pNameLineEdit;
    pNameLineEdit->setFixedSize(280,35);
    pNameLineEdit->setStyleSheet(sStyleLineEdit);
    pNameLineEdit->setPlaceholderText("您的账号");

    pNameLayout->addStretch();
    pNameLayout->addWidget(pNameLbl);
    pNameLayout->addSpacing(10);
    pNameLayout->addWidget(pNameLineEdit);
    pNameLayout->addStretch();

    QHBoxLayout* pPwdLayout=new QHBoxLayout(this);
    QLabel* pPwdLbl=new QLabel(this);
    pPwdLbl->setText("密 码");
    pPwdLbl->setStyleSheet(styleLbl);

    QLineEdit* pPwdLineEdit=new QLineEdit(this);
    m_pPwdLineEdit=pPwdLineEdit;
    pPwdLineEdit->setFixedSize(280,35);
    pPwdLineEdit->setStyleSheet(sStyleLineEdit);
    pPwdLineEdit->setPlaceholderText("您的密码");

    pPwdLayout->addStretch();
    pPwdLayout->addWidget(pPwdLbl);
    pPwdLayout->addSpacing(10);
    pPwdLayout->addWidget(pPwdLineEdit);
    pPwdLayout->addStretch();

    QString styleBtnSheet3 = QString("QPushButton{border:0px;background:transparent;font-family:'Microsoft YaHei';font-size:9pt;font-weight:Light;color: #0082E6}\
                                     PushButton:hover{color: #0082E6;}\
                                     QPushButton:pressed{color: #0082E6;}\
                                     QPushButton{background:transparent;}");

    QString styleBtnSheet2 = QString("QPushButton{border:0px;background: #2E6EE6;font-size: 16px;border-radius: 2px;font-family: Microsoft YaHei;font-weight: bold;color: #FFFFFF;}\
                                     PushButton:hover{color: #0082E6;}\
                                     QPushButton:pressed{color: #0082E6;}\
                                     QPushButton{background:#2E6EE6;}");

    QString styleBtnSheet1 = QString("QPushButton{border:0px;background: #0078D4;font-size: 16px;border-radius: 15px;font-family: Microsoft YaHei;font-weight: bold;color: #FFFFFF;}\
                                     PushButton:hover{color: #0082E6;}\
                                     QPushButton:pressed{color: #0078D4;}\
                                     QPushButton{background:#0078D4;}");

    QPushButton* pConfigBtn=new QPushButton("配置");
    pConfigBtn->setFixedSize(70,32);
    pConfigBtn->setStyleSheet(styleBtnSheet1);

    // 登录按钮
    QHBoxLayout* pRegisterLayout=new QHBoxLayout(this);
    pRegisterLayout->setContentsMargins(QMargins(0,0,0,0));
    pRegiserLayout->setSpacing(0);

    QPushButton* pRegisterBtn=new QPushButton();
    pRegisterBtn->setText("注册");
    pRegisterBtn->setFixedSize(70,32);
    pRegisterBtn->setStyleSheet(styleBtnSheet1);

    pRegisterLayout->addStretch();
    pRegisterLayout->addWidget(pRegisterBtn);
    pRegisterLayout->addSpacing(20);
    pRegisterLayout->addWidget(pConfigBtn);
    pRegisterLayout->addStretch();

    pMainLayout->addWidget(pTitleWgt);
    pMainLayout->addSpacing(30);
    pMainLayout->addLayout(pRegiserLayout);
    pMainLayout->addSpacing(30);
    pMainLayout->addLayout(pNameLayout);
    pMainLayout->addSpacing(20);
    pMainLayout->addLayout(pPwdLayout);
    pMainLayout->addSpacing(20);
    pMainLayout->addLayout(pRegisterLayout);
    pMainLayout->addStretch();

    connect(pRegisterBtn,&QPushButton::clicked,this,&QRegisterWidget::slotRegister);
    connect(pRegisterBtn,&QPushButton::clicked,this,&QRegisterWidget::WriteIni);
    connect(pConfigBtn,&QPushButton::clicked,this,&QRegisterWidget::slotServer);
}

void QRegisterWidget::slotRegister()
{
    QSqlQuery query;
    query.prepare("insert into admtable (admId, admPwd) "
                  "values(?,?)");
    query.addBindValue(m_pNameLineEdit->text());
    query.addBindValue(m_pPwdLineEdit->text());

    bool r=query.exec();
    if(!r)
    {
        QMessageBox::critical(this,"错误","插入失败！");
    }
    else
    {
        QMessageBox::information(this,"消息","插入成功");

        this->hide();
    }
}

// 配置窗口
void QRegisterWidget::slotServer()
{
    m_pServerInfo->show();
}

// 写入配置
void QRegisterWidget::WriteIni()
{
    ConfigIni().SetAccountIni(m_pNameLineEdit->text());
}

// 创建数据库
void QRegisterWidget::createdatebase()
{
    QString dbName="db2.db";
    QFileInfo info(dbName);// 提供有关文件名和文件系统中的位置，访问权限以及它时目录还是符号链接等信号
    bool isExits=info.exists();
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");// 添加数据库
    db.setHostName(dbHostName);       //选择本地主机
    db.setDatabaseName(dbName);       //设置数据源名称
    db.setUserName(dbusername);       //登录用户
    db.setPassword(dbpassword);       //密码
    bool isOpen=db.open();
    if(isOpen)
    {
        if(!isExits)
        {
            QSqlQuery query(db);

            // 存放账号与密码
             bool ok1=query.exec("CREATE TABLE admtable "
                                 "( admId nchar ( 10 ) PRIMARY KEY NOT NULL, admPwd nchar ( 20 ) NOT NULL);");
             bool ok2=query.exec("INSERT INTO admtable ( admId, admPwd) "
                                            "VALUES ( '456789', '12345678'),( '00002', '12345678');");
            if(ok1&&ok2)
                qDebug()<<"创建表成功";
            else
               qDebug()<<"创建表失败";
        }
        else qDebug()<<"表已存在";
    }


}

// 检查密码
bool QRegisterWidget::checkadmpassword(QString getId, QString getPass)
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setHostName(dbHostName);       //选择本地主机
    db.setDatabaseName("db2.db");     //设置数据源名称
    db.setUserName(dbusername);       //登录用户
    db.setPassword(dbpassword);       //密码
    bool isOpen=db.open();
    if(isOpen)
    {
        QSqlQuery query(db);

        query.exec("select admPwd from admtable where admId='"+getId+"'");
        query.next();//检索结果中的下一条记录，并将查询定位在检索到的记录上

        QString str=query.value(0).toString();
        str=removeSpace(str);
        qDebug()<<"获取到的密码是："<<str;
        if(str==getPass)
        {
            qDebug()<<"身份密码正确";
            return true;
        }
        else
        {
            qDebug()<<"身份密码错误";
            return false;
        }
    }
    return true;
}


// 保存聊天记录
void QRegisterWidget::SqlSaveChatRecord()
{

}
