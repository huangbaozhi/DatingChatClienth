#include "QNewsWidget.h"
#include "QChatWidget.h"
#include "QMyInfor.h"

#include <QLabel>
#include <QToolButton>
#include <QVBoxLayout>
#include <QStackedWidget>
#include <QSplitter>


QNewsWidget::QNewsWidget(QTcpSocket *socket, QString fri, QString group, QString userName, QWidget *parent)
    : QWidget(parent)
    , m_pChatWidgt(NULL)
{
    // 聊天界面
    QChatWidget* pChatWidgt=new QChatWidget(socket, fri, group, userName);
    m_pChatWidgt=pChatWidgt;
    connect(this,SIGNAL(signNewUserName()),pChatWidgt,SIGNAL(signChatUserName()));

    // 个人信息界面
    QMyInfor* pMyInfor=new QMyInfor(socket, fri, group, userName);
    m_pMyInfor=pMyInfor;
    pMyInfor->setStyleSheet("QWidget{border:0px;}");
    pMyInfor->setFixedSize(200,600);
    pMyInfor->setFixedWidth(200);

    this->initUI();
}

void QNewsWidget::initUI()
{
    this->setStyleSheet("QWidget{border: 1px solid #707070;border-left:0px;border-top:0px;}");

    QHBoxLayout* pMainLayout=new QHBoxLayout(this);
    pMainLayout->setContentsMargins(QMargins(0,0,0,0));
    pMainLayout->setSpacing(0);

    QWidget* pMiddleWgt=new QWidget(this);
    m_pMiddleWgt=pMiddleWgt;
    QVBoxLayout* pMiddleLayout=new QVBoxLayout(pMiddleWgt);
    m_pMiddleLayout=pMiddleLayout;
    pMiddleLayout->setContentsMargins(QMargins(0,0,0,0));
    pMiddleLayout->setSpacing(0);

    QStackedWidget* pChatStackedWidget=new QStackedWidget(this);
    pChatStackedWidget->setStyleSheet("border-right:0px;");
    pChatStackedWidget->setFixedWidth(600);
    m_pChatStackedWidget=pChatStackedWidget;
    pChatStackedWidget->addWidget(m_pChatWidgt);

    // 个人信息界面
    pMiddleLayout->addWidget(m_pMyInfor);
    pMainLayout->addWidget(pChatStackedWidget);
    pMainLayout->addWidget(pMiddleWgt);
}

void QNewsWidget::slotServer()
{
    m_pChatWidgt->slotConnectButton();
}

// 传入账号
void QNewsWidget::slotMyInfo(QString str)
{
    m_pMyInfor->slotGetSqlAccount(str);
}

