#include "QOperationWidget.h"
#include "clientfile.h"

#include <QHBoxLayout>
#include <QPushButton>

QOperationWidget::QOperationWidget(QWidget *parent) : QWidget(parent)
{
    this->initUI();
}

void QOperationWidget::initUI()
{
    QHBoxLayout* pMainLayout=new QHBoxLayout(this);
    pMainLayout->setContentsMargins(QMargins(0,0,0,0));
    pMainLayout->setSpacing(0);
    this->setStyleSheet("border:0px;");

    QPushButton* pSCreenshotBtn=new QPushButton();
    pSCreenshotBtn->setFixedSize(30,30);
    pSCreenshotBtn->setStyleSheet("QPushButton{background:url(:/image/cut.png);}");
    QPushButton* pSendFileBtn=new QPushButton();
    pSendFileBtn->setFixedSize(30,30);
    pSendFileBtn->setStyleSheet("QPushButton{background:url(:/image/file.png);}");
    connect(pSendFileBtn,&QPushButton::clicked,this,&QOperationWidget::slotfileTransfer);

    // 聊天记录
    QPushButton* pChatRecordBtn=new QPushButton();
    pChatRecordBtn->setFixedSize(30,30);
    pChatRecordBtn->setStyleSheet("QPushButton{background:url(:/image/chatlog.png);}");
    //QPushButton* pSendPicturesBtn=new QPushButton("发送图片");
    connect(pChatRecordBtn,&QPushButton::clicked,this,&QOperationWidget::signSQLChatRecord);

   // pMainLayout->addStretch();
    pMainLayout->addWidget(pSCreenshotBtn);
    pMainLayout->addSpacing(20);
    pMainLayout->addWidget(pSendFileBtn);
    pMainLayout->addSpacing(20);
    pMainLayout->addWidget(pChatRecordBtn);
    //pMainLayout->addSpacing(20);
    //pMainLayout->addWidget(pSendPicturesBtn);
    pMainLayout->addStretch();
}


// 文件传输
void QOperationWidget::slotfileTransfer()
{
    qDebug()<<"SlotFileTransFer===";

    ClientFile clienFile;
    clienFile.exec();
}
