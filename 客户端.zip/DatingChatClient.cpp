#include "DatingChatClient.h"
#include "ui_DatingChatClient.h"
#include "QContactsWidget.h"
#include "QNewsWidget.h"
#include "QLoginWidget.h"
#include "QRegisterWidget.h"
#include "QMyInfor.h"
#include "QSetWidget.h"
#include "QMovableWindow.h"
#include "QHeadImage.h"
#include "globle.h"

#include <QPushButton>
#include <QLabel>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QListWidget>
#include <QSplitter>
#include <QStackedWidget>
#include <QListWidget>
#include <QLineEdit>
#include <QTextBrowser>
#include <QImage>
#include <QFileInfo>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>

DatingChatClient::DatingChatClient(QTcpSocket *socket, QString fri, QString group, QString userName, QWidget *parent)
     : QWidget(parent)
    , ui(new Ui::DatingChatClient)
{
    //ui->setupUi(this);

    // 消息界面
    m_pNewsWidget=new QNewsWidget(socket, fri, group, userName);
    connect(this,SIGNAL(signOnlineUserName()),m_pNewsWidget,SIGNAL(signNewUserName()));

    // 联系人界面
    m_pContactsWidget=new QContactsWidget(socket, fri, group, userName);

    // 设置界面
    m_pSetWidget=new QSetWidget(socket, fri, group, userName);


    this->initUI();
    this->signAndslot();
    displayImage(m_Ppix);
    SQLSaveChatRecord();// 数据库存储聊天记录
}

DatingChatClient::~DatingChatClient()
{
    delete ui;
}

// 初始化界面
void DatingChatClient::initUI()
{
    (void)new QMovableWindow(this);
    this->setStyleSheet("background:#ffffff;border: 1px solid #707070;");
    this->setFixedHeight(700);

    QVBoxLayout* pVMainLayout=new QVBoxLayout(this);
    pVMainLayout->setContentsMargins(0,0,0,0);
    pVMainLayout->setSpacing(0);

    QHBoxLayout* pMainLayout=new QHBoxLayout(this);
    m_pMainLayout=pMainLayout;
    pMainLayout->setContentsMargins(0,0,0,0);
    pMainLayout->setSpacing(0);

    // 标题栏
    QWidget* pTitleWgt=new QWidget();
    pTitleWgt->setStyleSheet("QWidget{background-color:#55b5ff;border-bottom:0px;}");
    QHBoxLayout* pTitleLyt=new QHBoxLayout(pTitleWgt);
    pTitleLyt->setContentsMargins(QMargins(0,0,0,0));
    pTitleLyt->setSpacing(0);

    QString styleSheet = QString("QPushButton{border-image: url(:/botton/nav_window_error_nor_58x40px.png);}\
                                  QPushButton:hover{border-image: url(:/botton/nav_window_error_hover_58x40px.png);}\
                                  QPushButton:pressed{border-image: url(:/botton/nav_window_error_click_58x40px.png);}\
                                  QPushButton{background:transparent;}");

   QString styleMinSheet = QString("QPushButton{border-image: url(:/botton/nav_window_narrow_nor_58x40px.png);}\
                                    PushButton:hover{border-image: url(:/botton/nav_window_narrow_hover_58x40px.png);}\
                                    QPushButton:pressed{border-image: url(:/botton/nav_window_narrow_click_58x40px.png);}\
                                    QPushButton{background:transparent;}");

    QLabel* pTitleLoginLbl=new QLabel();
    pTitleLoginLbl->setFixedSize(30,30);
    pTitleLoginLbl->setStyleSheet("QLabel{border-image:url(:/image/logo_3.png);}");
    QPushButton* pMinBtn=new QPushButton();
    pMinBtn->setFixedSize(58,40);
    pMinBtn->setStyleSheet(styleMinSheet);
    QPushButton* pCloseBtn=new QPushButton();
    pCloseBtn->setFixedSize(58,40);
    pCloseBtn->setStyleSheet(styleSheet);

    pTitleLyt->addSpacing(10);
    pTitleLyt->addWidget(pTitleLoginLbl);
    pTitleLyt->addStretch();
    pTitleLyt->addWidget(pMinBtn);
    pTitleLyt->addWidget(pCloseBtn);

    connect(pMinBtn,&QPushButton::clicked,this,&QRegisterWidget::showMinimized);
    connect(pCloseBtn,&QPushButton::clicked,this,&QRegisterWidget::close);


    QString styWgt="QWidget{background: #ffffff;border-right:0px;border-top:0px;}";
    // 左侧栏
    QWidget* pLeftWgt=new QWidget();
    pLeftWgt->setStyleSheet(styWgt);
    pLeftWgt->setFixedWidth(80);
    QVBoxLayout* pLeftLayout=new QVBoxLayout(pLeftWgt);
    pLeftLayout->setContentsMargins(0,0,0,0);
    pLeftLayout->setSpacing(0);

    // 设置头像
    QHBoxLayout* pLogoLayout=new QHBoxLayout();
    pLogoLayout->setContentsMargins(QMargins(0,0,0,0));
    pLogoLayout->setSpacing(0);

    QString sty="border:0px;border-image:url(:/image/zzzz.jpg)";
    m_pHeadLbl=new QLabel();
    m_pHeadLbl->setFixedSize(60,60);
    m_pHeadLbl->setStyleSheet(sty);

    pLogoLayout->addStretch();
    pLogoLayout->addWidget(m_pHeadLbl);
    pLogoLayout->addStretch();


    QString styleBtnSheet1 = QString("QPushButton{padding-left:2px;border:0px;background:transparent;font-family:'Microsoft YaHei';font-size:16px;font-weight:Light;color: #0082E6}\
                                     PushButton:hover{color: #0082E6;}\
                                     QPushButton:pressed{color: #0082E6;}\
                                     QPushButton{background:transparent;}");

    QString styleBtnSheet = QString("QPushButton{border:0px;background: #55b5ff;font-size: 16px;border-radius: 2px;font-family: Microsoft YaHei;font-weight: bold;color: #FFFFFF;}\
                                     PushButton:hover{color: #0082E6;}\
                                     QPushButton:pressed{color: #55b5ff;}\
                                     QPushButton{background:#55b5ff;}");

    QPushButton* pNewsBtn=new QPushButton("消息");
    m_pNewsBtn=pNewsBtn;
    pNewsBtn->setFixedHeight(40);
    pNewsBtn->setStyleSheet(styleBtnSheet);

    QPushButton* pContactsBtn=new QPushButton("联系人");
    m_pContactsBtn=pContactsBtn;
    pContactsBtn->setFixedHeight(40);
    pContactsBtn->setStyleSheet(styleBtnSheet);

    QPushButton* pSetBtn=new QPushButton("设置");
    m_pSetBtn=pSetBtn;
    pSetBtn->setFixedHeight(40);
    pSetBtn->setStyleSheet(styleBtnSheet);

    pLeftLayout->addSpacing(10);
   // pLeftLayout->addWidget(m_pHeadLbl);
    pLeftLayout->addLayout(pLogoLayout);
    pLeftLayout->addSpacing(10);
    pLeftLayout->addWidget(pNewsBtn);
    pLeftLayout->addSpacing(10);
    pLeftLayout->addWidget(pContactsBtn);
    pLeftLayout->addStretch();
    pLeftLayout->addWidget(pSetBtn);
    pLeftLayout->addSpacing(10);

    // 栈窗口_中间栏
    QStackedWidget* pMiddleStackedWidget=new QStackedWidget(this);
    m_pMiddleStackedWidget=pMiddleStackedWidget;
    pMiddleStackedWidget->setStyleSheet("border:0px;background:#f5f5f5;");

    pMiddleStackedWidget->addWidget(m_pNewsWidget);
    pMiddleStackedWidget->addWidget(m_pContactsWidget);
    pMiddleStackedWidget->addWidget(m_pSetWidget);

    pMainLayout->addWidget(pLeftWgt);
    pMainLayout->addWidget(pMiddleStackedWidget);

    pVMainLayout->addWidget(pTitleWgt);
    pVMainLayout->addLayout(pMainLayout);
}

void DatingChatClient::signAndslot()
{
    connect(m_pNewsBtn,&QPushButton::clicked, this, &DatingChatClient::turnPages);
    connect(m_pContactsBtn, &QPushButton::clicked, this, &DatingChatClient::turnPages);
    connect(m_pSetBtn, &QPushButton::clicked, this, &DatingChatClient::turnPages);
}

// 连接服务器
void DatingChatClient::slotConnectSever()
{
    m_pNewsWidget->slotServer();
}

// 获取账号ID
void DatingChatClient::slotGetAccountID(QString str)
{
    m_pNewsWidget->slotMyInfo(str);     // 传入账号到聊天界面中的消息信息
    m_pSetWidget->slotGetAccount(str);  // 传入账号到配置界面中的详细信息
}

// 翻页
void DatingChatClient::turnPages()
{
    QPushButton* pBtn=dynamic_cast<QPushButton*>(QObject::sender());
    if(!pBtn) return;

    if(pBtn==m_pNewsBtn&&m_pNewsWidget)
    {
        m_pMiddleStackedWidget->setCurrentWidget(m_pNewsWidget);
    }
    else if(pBtn==m_pContactsBtn&&m_pContactsWidget)
    {
        m_pMiddleStackedWidget->setCurrentWidget(m_pContactsWidget);
    }
    else if(pBtn==m_pSetBtn&&m_pSetWidget)
    {
        m_pMiddleStackedWidget->setCurrentWidget(m_pSetWidget);
    }
}

// 数据库保存聊天记录
void DatingChatClient::SQLSaveChatRecord()
{
    QString dbName="db2.db";
    QFileInfo info(dbName);// 提供有关文件名和文件系统中的位置，访问权限以及它时目录还是符号链接等信号
    bool isExits=info.exists();
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");// 添加数据库
    db.setHostName(dbHostName);       //选择本地主机
    db.setDatabaseName(dbName);       //设置数据源名称
    db.setUserName(dbusername);       //登录用户
    db.setPassword(dbpassword);       //密码
    bool isOpen=db.open();
    if(isOpen)
    {
        if(!isExits)
        {
            QSqlQuery query(db);
            // 存储聊天内容
             bool ok1=query.exec("CREATE TABLE chatRecordtable "
                                 "( chatRecord	TEXT NOT NULL);");
             bool ok2=query.exec("INSERT INTO chatRecordtable (chatRecord) "
                                            "VALUES ('黄宝知'),('lanzhou');");

            if(ok1&&ok2)
                qDebug()<<"创建表成功";
            else
               qDebug()<<"创建表失败";
        }
        else qDebug()<<"表已存在";
    }
}


void DatingChatClient::displayImage(QPixmap pix)
{
    m_Ppix=pix;
    if(!pix.isNull())
    {
        m_pHeadLbl->setPixmap(m_Ppix);
    }
    else
    {
        QString fileName="E:/school/hbzProject/DatingChatClienthbz/testImage/2.jpg";
        m_pHeadLbl->setPixmap(QPixmap(fileName));
    }
    m_pHeadLbl->setScaledContents(true);
}


