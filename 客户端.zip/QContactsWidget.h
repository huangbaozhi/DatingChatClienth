#ifndef QCONTACTSWIDGET_H
#define QCONTACTSWIDGET_H

#include <QWidget>
#include <QVector>
#include <QTcpSocket>

class QListWidget;
class QByteArray;
class QHBoxLayout;
class QStackedWidget;
class Chatlist;

class QContactsWidget : public QWidget
{
    Q_OBJECT
public:
    explicit QContactsWidget(QTcpSocket *s, QString fri, QString group, QString u, QWidget *parent = nullptr);

signals:
    void signlistPage();
    void signchatListPage();

private:
    void initUI();// 初始化窗口

public:

private slots:
    void listPage();
    void chatListPage();//聊天列表页

private:
    QListWidget* m_pListWidget;
    QByteArray* m_ByteArray;
    QStringList m_list;

    QHBoxLayout* m_pMainLayout;
    QStackedWidget* m_pStackedWidget;


    Chatlist *m_c;

};

#endif // QCONTACTSWIDGET_H
