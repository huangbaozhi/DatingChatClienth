﻿#ifndef QRBASEWIDGET_H
#define QRBASEWIDGET_H

#include <QDialog>

class QRBaseWidget : public QDialog
{
    Q_OBJECT
public:
    explicit QRBaseWidget(QWidget *parent = nullptr);

public:
    virtual void WriteIni();				// 写出ini配置接口

signals:

};

#endif // QRBASEWIDGET_H
