#ifndef QSERVERWIDGET_H
#define QSERVERWIDGET_H

#include <QWidget>

class WriteConfigIni : public QWidget
{
    Q_OBJECT
public:
    explicit WriteConfigIni(QWidget *parent = nullptr);

    virtual void WriteIni();

signals:

private:

};

#endif // QSERVERWIDGET_H
