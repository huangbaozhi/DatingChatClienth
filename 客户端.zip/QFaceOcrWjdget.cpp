#include "QFaceOcrWjdget.h"

#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QCamera>
#include <QCameraViewfinder>
#include <QCameraImageCapture>
#include <QCameraInfo>
#include <QDebug>
#include <QPixmap>

QFaceOcrWjdget::QFaceOcrWjdget(QWidget *parent) : QWidget(parent)
{
    initUI();
}

void QFaceOcrWjdget::initUI()
{
    QVBoxLayout* pMainLayout=new QVBoxLayout(this);


    //摄像头获取
    m_pCamera = new QCamera(this);
    viewfinder = new QCameraViewfinder(this);
    imageCapture = new QCameraImageCapture(m_pCamera);

    m_pButtonCapture=new QPushButton();
    m_pImageView=new QHBoxLayout();
    m_pImageView->addSpacing(6);
    QLabel* pOcrLbl=new QLabel("识别结果：");

    pMainLayout->addWidget(m_pButtonCapture);
    pMainLayout->addLayout(m_pImageView);
    pMainLayout->addWidget(pOcrLbl);

    m_pImageView->addWidget(viewfinder);
     m_pCamera->setViewfinder(viewfinder);



}
