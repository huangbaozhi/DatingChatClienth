﻿#include "QIniConfig.h"

#include <QCoreApplication>
#include <QSettings>
#include <QLabel>
#include <QFile>
#include <QDebug>

QIniConfig::QIniConfig()
{
    this->CreateFile();
}

QIniConfig::~QIniConfig()
{
    delete m_psetting;
    m_psetting = NULL;
}

// 获取文件路径
void QIniConfig::CreateFile()
{
    m_FileName = QCoreApplication::applicationDirPath() + "/config.ini";
    qDebug() << "m_FileName: " << m_FileName;

    //"Config.ini"配置文件，文件存在则打开，不存在则创建
    m_psetting = new QSettings(m_FileName, QSettings::IniFormat);
}

void QIniConfig::SetRealNameAutIni(QString name,QString id)
{
    m_psetting->setValue("/OCR/Name",name);
    m_psetting->setValue("/OCR/ID",id);
}

// 获取实名认证配置
QString QIniConfig::GetRealNameAutIni()
{
    return m_psetting->value("/OCR/Name").toString();
}

QString QIniConfig::GetRealIdAutIni()
{
    return m_psetting->value("/OCR/ID").toString();
}

