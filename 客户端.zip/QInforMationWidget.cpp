#include "QInforMationWidget.h"
#include "ConfigIni.h"

#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QDebug>

QInforMationWidget::QInforMationWidget(QTcpSocket *socket, QString fri, QString group, QString userName, QWidget *parent)
    : QRBaseWidget(parent)
    , m_pFullNameEdit(NULL)
    , m_pIDEdit(NULL)
    , status(false)
{
    //this->setStyleSheet("border: 1px solid #707070;");

    status=false;
    // 初始化界面
    initUI();

    if(userName==NULL)
    {
        // 读取配置
        m_pNameEdit->setText(ConfigIni().GetName());                    // 昵称
        m_pIpEdit->setText(ConfigIni().GetIp());                        // IP地址
        m_pPortEdit->setText(ConfigIni().GetPort());                    // 端口号
        m_pFullNameEdit->setText(ConfigIni().GetRealNameAutIni());      // 名字
        m_pIDEdit->setText(ConfigIni().GetRealIdAutIni());              // 身份证号
    }
    else
    {
        m_pNameEdit->setText(userName);
        m_pIpEdit->setText("122.112.250.76");
        m_pAccoutnEdit->setText(userName);
        m_pPortEdit->setText("22");
        m_pFullNameEdit->setText(userName);
        m_pIDEdit->setText("52272819902105744");
    }
}

// 初始化界面
void QInforMationWidget::initUI()
{
    QVBoxLayout* pMainLayout=new QVBoxLayout(this);
    pMainLayout->setContentsMargins(QMargins(0,0,0,0));
    pMainLayout->setSpacing(0);

    QString style="padding-left:200px;font-size: 18px;font-family: Microsoft YaHei;font-weight: bold;border: 1px solid #707070;border-left:0px;border-top:0xp;border-bottom:0px;border-right:0xp;";
    QString style1="font-size: 16px;font-family: Microsoft YaHei;";

    // 详细信息
//    QHBoxLayout* pInforLayout=new QHBoxLayout();
//    pInforLayout->setContentsMargins(QMargins(0,0,0,0));
//    pInforLayout->setSpacing(0);

    QLabel* pInforLbl=new QLabel("个人详细信息");
    pInforLbl->setStyleSheet(style);

   // pInforLayout->addWidget(pInforLbl);

    // 昵称
    QHBoxLayout* pNameLayout=new QHBoxLayout();
    pNameLayout->setContentsMargins(QMargins(0,0,0,0));
    pNameLayout->setSpacing(0);

    QString styleEdit="QLineEdit{border-radius: 2px;border: 1px solid #2E6EE6;;background: #FFFFFF;color: #333333;}";

    QLabel* pNameLbl=new QLabel("昵   称");
    pNameLbl->setFixedSize(50,32);
    pNameLbl->setStyleSheet(style1);
    QLineEdit* pNameEdit=new QLineEdit();
    m_pNameEdit=pNameEdit;
    pNameEdit->setFixedHeight(32);
    pNameEdit->setStyleSheet(styleEdit);

    pNameLayout->addSpacing(130);
    pNameLayout->addWidget(pNameLbl);
    pNameLayout->addSpacing(20);
    pNameLayout->addWidget(pNameEdit);
    pNameLayout->addStretch();

    // 账号
    QHBoxLayout* pAccountLayout=new QHBoxLayout();
    pAccountLayout->setContentsMargins(QMargins(0,0,0,0));
    pAccountLayout->setSpacing(0);

    QLabel* pAccountLbl=new QLabel("账   号");
    pAccountLbl->setFixedSize(50,32);
    pAccountLbl->setStyleSheet(style1);
    QLineEdit* pAccoutnEdit=new QLineEdit();
    m_pAccoutnEdit=pAccoutnEdit;
    pAccoutnEdit->setFixedHeight(32);
    pAccoutnEdit->setStyleSheet(styleEdit);

    pAccountLayout->addSpacing(130);
    pAccountLayout->addWidget(pAccountLbl);
    pAccountLayout->addSpacing(20);
    pAccountLayout->addWidget(pAccoutnEdit);
    pAccountLayout->addStretch();

    // IP地址
    QHBoxLayout* pIpLayout=new QHBoxLayout();
    pIpLayout->setContentsMargins(QMargins(0,0,0,0));
    pIpLayout->setSpacing(0);

    QLabel* pIpLbl=new QLabel("IP地址");
    pIpLbl->setFixedSize(50,32);
    pIpLbl->setStyleSheet(style1);
    QLineEdit* pIpEdit=new QLineEdit();
    m_pIpEdit=pIpEdit;
    pIpEdit->setFixedHeight(32);
    pIpEdit->setStyleSheet(styleEdit);

    pIpLayout->addSpacing(130);
    pIpLayout->addWidget(pIpLbl);
    pIpLayout->addSpacing(20);
    pIpLayout->addWidget(pIpEdit);
    pIpLayout->addStretch();

    // 端口号
    QHBoxLayout* pPortLayout=new QHBoxLayout();
    pPortLayout->setContentsMargins(QMargins(0,0,0,0));
    pPortLayout->setSpacing(0);

    QLabel* pPortLbl=new QLabel("端口号");
    pPortLbl->setFixedSize(50,32);
    pPortLbl->setStyleSheet(style1);
    QLineEdit* pPortEdit=new QLineEdit();
    m_pPortEdit=pPortEdit;
    pPortEdit->setFixedHeight(32);
    pPortEdit->setStyleSheet(styleEdit);

    pPortLayout->addSpacing(130);
    pPortLayout->addWidget(pPortLbl);
    pPortLayout->addSpacing(20);
    pPortLayout->addWidget(pPortEdit);
    pPortLayout->addStretch();

    // 姓名
    QHBoxLayout* pFullNameLayout=new QHBoxLayout();
    pFullNameLayout->setContentsMargins(QMargins(0,0,0,0));
    pFullNameLayout->setSpacing(0);

    QLabel* pFullNameLbl=new QLabel("姓   名");
    pFullNameLbl->setFixedSize(50,32);
    pFullNameLbl->setStyleSheet(style1);
    QLineEdit* pFullNameEdit=new QLineEdit();
    m_pFullNameEdit=pFullNameEdit;
    pFullNameEdit->setFixedHeight(32);
    pFullNameEdit->setStyleSheet(styleEdit);

    pFullNameLayout->addSpacing(130);
    pFullNameLayout->addWidget(pFullNameLbl);
    pFullNameLayout->addSpacing(20);
    pFullNameLayout->addWidget(pFullNameEdit);
    pFullNameLayout->addStretch();

    // 身份证号
    QHBoxLayout* pIDLayout=new QHBoxLayout();
    pIDLayout->setContentsMargins(QMargins(0,0,0,0));
    pIDLayout->setSpacing(0);

    QLabel* pIDLbl=new QLabel("身份证");
    pIDLbl->setFixedSize(50,32);
    pIDLbl->setStyleSheet(style1);
    QLineEdit* pIDEdit=new QLineEdit();
    m_pIDEdit=pIDEdit;
    pIDEdit->setFixedHeight(32);
    pIDEdit->setStyleSheet(styleEdit);

    pIDLayout->addSpacing(130);
    pIDLayout->addWidget(pIDLbl);
    pIDLayout->addSpacing(20);
    pIDLayout->addWidget(pIDEdit);
    pIDLayout->addStretch();

    QString styleSaveSheet = QString("QPushButton{border: 0px;width: 28px;height: 9px;font-size: 16px;font-family: Microsoft YaHei;font-weight: bold;color: #FFFFFF;border-image: url(:/botton/login_btn_nor_288x48px.png);}\
                                     PushButton:hover{border-image: url(:/botton/login_btn_hover_288x48px.png);}\
                                     QPushButton:pressed{border-image: url(:/botton/login_btn_click_288x48px.png);}\
                                     QPushButton{background:transparent;}");

    // 按钮
    QHBoxLayout* pBtnLayout=new QHBoxLayout();
    pBtnLayout->setContentsMargins(QMargins(0,0,0,0));
    pBtnLayout->setSpacing(0);

    QPushButton* pModifyBtn=new QPushButton("修改");
    pModifyBtn->setStyleSheet(styleSaveSheet);
    pModifyBtn->setFixedHeight(32);

    QPushButton* pSaveBtn=new QPushButton("保存");
    pSaveBtn->setStyleSheet(styleSaveSheet);
    pSaveBtn->setFixedHeight(32);

    connect(pModifyBtn,&QPushButton::clicked,this,&QInforMationWidget::slotModify);
    connect(pSaveBtn,&QPushButton::clicked,this,&QInforMationWidget::WriteIni);

    pBtnLayout->addSpacing(70);
    pBtnLayout->addWidget(pModifyBtn);
    pBtnLayout->addSpacing(20);
    pBtnLayout->addWidget(pSaveBtn);
    pBtnLayout->addSpacing(70);

    pMainLayout->addSpacing(40);
    pMainLayout->addWidget(pInforLbl);
    pMainLayout->addSpacing(40);
    pMainLayout->addLayout(pNameLayout);
    pMainLayout->addSpacing(20);
    pMainLayout->addLayout(pAccountLayout);
    pMainLayout->addSpacing(20);
    pMainLayout->addLayout(pIpLayout);
    pMainLayout->addSpacing(20);
    pMainLayout->addLayout(pPortLayout);
    pMainLayout->addSpacing(20);
    pMainLayout->addLayout(pFullNameLayout);
    pMainLayout->addSpacing(20);
    pMainLayout->addLayout(pIDLayout);
    pMainLayout->addSpacing(30);
    pMainLayout->addLayout(pBtnLayout);
    pMainLayout->addStretch();
}

// 修改按钮
void QInforMationWidget::slotModify()
{
//    if(status==false)
//    {
//        m_pNameEdit->setEnabled(false);
//    }
//    //如果当前时在线状态，则断开和服务器连接
//    else
//    {
//        m_pNameEdit->setEnabled(true);
//    }

}


// 写入配置
void QInforMationWidget::WriteIni()
{
    // 名字、身份证号
    ConfigIni().SetRealNameAutIni(m_pFullNameEdit->text(),m_pIDEdit->text());

    // 昵称、IP地址、端口号
    ConfigIni().SetNameAndIpIni(m_pNameEdit->text(),m_pIpEdit->text(),m_pPortEdit->text());
}

void QInforMationWidget::slotGetAccount(QString account)
{
    qDebug()<<"测试账号==Info11"<<account;
    m_sAccount=account;
    m_pAccoutnEdit->setText(m_sAccount);
    qDebug()<<"测试账号2333=="<<m_sAccount;
}

